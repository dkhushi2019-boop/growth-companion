(function(){
'use strict';
var UIKEY='gc-ui-v1';
var TZ_C='Asia/Kolkata', TZ_P='Asia/Dubai';
var DOW=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var DOWL=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var MONL=['January','February','March','April','May','June','July','August','September','October','November','December'];

/* ---------- icons ---------- */
var IC={
  today:'<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2.5 12h2M19.5 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  plan:'<rect x="3.5" y="4.5" width="17" height="16" rx="2.5"/><path d="M3.5 9.5h17M8 2.5v4M16 2.5v4M7.5 13.5h3M7.5 16.5h6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  progress:'<path d="M5 20v-6M10 20V9M15 20v-4M20 20V5"/>',
  gift:'<rect x="3.5" y="8" width="17" height="5" rx="1"/><path d="M5.5 13v7.5h13V13M12 8v12.5M12 8C10.5 4.5 7 4 7 6.2 7 7.6 9 8 12 8zM12 8c1.5-3.5 5-4 5-1.8C17 7.6 15 8 12 8z"/>',
  home:'<path d="M3.5 11 12 4l8.5 7"/><path d="M5.5 9.5v10.5h13V9.5M10 20v-5.5h4V20"/>',
  week:'<rect x="3.5" y="4.5" width="17" height="16" rx="2.5"/><path d="M3.5 9h17M8 17v-3M12 17v-5M16 17v-2"/>',
  chat:'<path d="M20.5 11.5a8 8 0 0 1-11.7 7.1L4 20l1.4-4.4a8 8 0 1 1 15.1-4.1z"/>',
  family:'<circle cx="8.5" cy="7.5" r="3"/><circle cx="16.5" cy="9.5" r="2.3"/><path d="M3 20c0-3.1 2.5-5.6 5.5-5.6S14 16.9 14 20M15 14.6c2.8 0 5 2.1 5 5.4"/>',
  book:'<path d="M4.5 19V5.5A2 2 0 0 1 6.5 3.5h13v15h-13a2 2 0 0 0-2 2 2 2 0 0 0 2 2h13"/><path d="M8.5 7.5h7"/>',
  pencil:'<path d="M15.5 4.5l4 4L8.5 19.5H4.5v-4z"/><path d="M13 7l4 4"/>',
  ball:'<circle cx="12" cy="12" r="8.5"/><path d="M6 6c2.8 2.6 2.8 9.4 0 12M18 6c-2.8 2.6-2.8 9.4 0 12"/>',
  palette:'<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 1.9-.9 1.5-2-.5-1.3.3-2.7 1.7-2.7h2.3a3 3 0 0 0 3-3c0-5.1-3.8-9.3-8.5-9.3z"/><circle cx="7.5" cy="11" r="1.1"/><circle cx="10" cy="7.2" r="1.1"/><circle cx="14.5" cy="7.2" r="1.1"/>',
  leaf:'<path d="M5 19.5c0-8.5 5.5-14 15-14 0 9-5.5 14.5-14 14.5"/><path d="M5 19.5l7.5-7.5"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  star:'<path d="M12 3.2l2.6 5.4 5.9.8-4.3 4.2 1 5.9L12 16.7l-5.2 2.8 1-5.9-4.3-4.2 5.9-.8z"/>',
  flame:'<path d="M12 21c-3.9 0-6.8-2.7-6.8-6.4 0-3.2 2.1-5.2 3.6-6.8.3 1.9 1.2 3.1 2.3 3.5C11 7.6 12.5 4.8 15 3.2c-.3 3.1 1.4 4.9 2.5 6.5.9 1.3 1.3 2.7 1.3 4.2 0 4.2-2.9 7.1-6.8 7.1z"/>',
  clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  chev:'<path d="M9.5 6l6 6-6 6"/>',
  x:'<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  trash:'<path d="M4.5 7h15M10 11v6M14 11v6M6.5 7l1 13h9l1-13M9.5 7V4.5h5V7"/>',
  send:'<path d="M4.5 12 19.5 4.5 15 19.5l-3-6z"/><path d="M12 13.5l7.5-9"/>',
  bell:'<path d="M6.5 16v-5a5.5 5.5 0 0 1 11 0v5l1.5 2h-14z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
  lock:'<rect x="5.5" y="10.5" width="13" height="10" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
  eye:'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  school:'<path d="M2.5 9 12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11v5c3 2.3 8 2.3 11 0v-5M21.5 9v5"/>',
  moon:'<path d="M19.5 14.5A7.5 7.5 0 1 1 9.5 4.5a6 6 0 0 0 10 10z"/>',
  meal:'<path d="M7 3.5v7M5 3.5v4.5a2 2 0 0 0 4 0V3.5M7 10.5v10M17 3.5c-2 0-3 2.5-3 6h3v11"/>',
  video:'<rect x="3" y="6.5" width="12.5" height="11" rx="2"/><path d="M15.5 10.5 21 7.5v9l-5.5-3"/>',
  heart:'<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',
  target:'<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
  shield:'<path d="M12 3.5 19 6v5.5c0 4.5-3 7.6-7 9-4-1.4-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/>',
  tablet:'<rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
  ext:'<path d="M14 4.5h5.5V10M19.5 4.5 11 13"/><path d="M17.5 13.5v5a1.5 1.5 0 0 1-1.5 1.5H6a1.5 1.5 0 0 1-1.5-1.5v-10A1.5 1.5 0 0 1 6 7h5"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>'
};
function ic(n,c){return '<svg class="ic'+(c?' '+c:'')+'" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(IC[n]||'')+'</g></svg>';}

/* ---------- backend ---------- */
var API=(function(){
  if(window.GC_API)return window.GC_API;
  var cfg=window.GC_CONFIG;
  if(!cfg||!cfg.url||!window.supabase)return null;
  var sb=window.supabase.createClient(cfg.url,cfg.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'gc-auth'}});
  function chk(r){if(r&&r.error)throw r.error;return r?r.data:null;}
  function childEmail(code){return 'child.'+String(code||'').trim().toLowerCase()+'@example.com';}
  var channel=null;
  return {
    vapidPublic:cfg.vapidPublic,
    session:function(){return sb.auth.getSession().then(function(r){return r.data.session;});},
    onAuth:function(cb){sb.auth.onAuthStateChange(function(ev,s){cb(ev,s);});},
    signUp:function(email,pw){return sb.auth.signUp({email:email,password:pw}).then(chk);},
    signIn:function(email,pw){return sb.auth.signInWithPassword({email:email,password:pw}).then(chk);},
    signInChild:function(code,pw){return sb.auth.signInWithPassword({email:childEmail(code),password:pw}).then(chk);},
    resetEmail:function(email){return sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname}).then(chk);},
    setPassword:function(pw){return sb.auth.updateUser({password:pw}).then(chk);},
    signOut:function(){if(channel){sb.removeChannel(channel);channel=null;}return sb.auth.signOut();},
    me:async function(){
      var u=(await sb.auth.getUser()).data.user;if(!u)return null;
      var m=chk(await sb.from('members').select('family_id,role').eq('user_id',u.id).maybeSingle());
      var out={userId:u.id,email:u.email};
      if(!m)return out;
      var f=chk(await sb.from('families').select('code').eq('id',m.family_id).single());
      var ms=chk(await sb.from('members').select('role'));
      out.familyId=m.family_id;out.role=m.role;out.code=f.code;
      out.hasChild=(ms||[]).some(function(x){return x.role==='child';});
      return out;
    },
    createFamily:async function(){return chk(await sb.rpc('create_family'));},
    loadItems:async function(fid){
      var all=[],from=0;
      for(;;){
        var rows=chk(await sb.from('items').select('kind,key,data').eq('family_id',fid).order('kind').order('key').range(from,from+999));
        all=all.concat(rows||[]);if(!rows||rows.length<1000)break;from+=1000;
      }
      return all;
    },
    upsert:async function(fid,rows){
      chk(await sb.from('items').upsert(rows.map(function(r){return {family_id:fid,kind:r.kind,key:r.key,data:r.data};}),{onConflict:'family_id,kind,key'}));
    },
    remove:async function(fid,rows){
      var by={};rows.forEach(function(r){(by[r.kind]=by[r.kind]||[]).push(r.key);});
      for(var k in by){chk(await sb.from('items').delete().eq('family_id',fid).eq('kind',k).in('key',by[k]));}
    },
    subscribe:function(fid,cb){
      if(channel)sb.removeChannel(channel);
      channel=sb.channel('items-'+fid)
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'items',filter:'family_id=eq.'+fid},function(p){cb('UPSERT',p.new);})
        .on('postgres_changes',{event:'UPDATE',schema:'public',table:'items',filter:'family_id=eq.'+fid},function(p){cb('UPSERT',p.new);})
        .on('postgres_changes',{event:'DELETE',schema:'public',table:'items'},function(p){if(p.old&&p.old.family_id===fid)cb('DELETE',p.old);})
        .subscribe();
    },
    setChildPassword:async function(pw){
      var r=await sb.functions.invoke('child',{body:{password:pw}});
      if(r.error){var msg=r.error.message;try{var j=await r.error.context.json();if(j&&j.error)msg=j.error;}catch(e){}throw new Error(msg);}
      return r.data;
    },
    savePush:async function(sub){chk(await sb.rpc('save_push',{sub:sub}));},
    removePush:async function(endpoint){chk(await sb.rpc('remove_push',{p_endpoint:endpoint}));},
    testPush:async function(){chk(await sb.rpc('test_push'));}
  };
})();

/* ---------- helpers ---------- */
function $(s){return document.querySelector(s);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function uid(){return Math.random().toString(36).slice(2,10);}
function sum(a,f){var s=0;for(var i=0;i<a.length;i++){s+=(f(a[i])||0);}return s;}
function parts(tz,date){var o={};new Intl.DateTimeFormat('en-GB',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date||new Date()).forEach(function(p){o[p.type]=p.value;});return o;}
function todayStr(){var p=parts(TZ_C);return p.year+'-'+p.month+'-'+p.day;}
function dateOf(ts,tz){var p=parts(tz,new Date(ts));return p.year+'-'+p.month+'-'+p.day;}
function nowMin(){var p=parts(TZ_C);return (+p.hour%24)*60+(+p.minute);}
function hourIn(tz){return +parts(tz).hour%24;}
function addDays(s,n){var d=new Date(s+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
function wd(s){return new Date(s+'T00:00:00Z').getUTCDay();}
function diffDays(a,b){return Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/864e5);}
function fmtShort(s){var d=new Date(s+'T00:00:00Z');return DOW[d.getUTCDay()]+' '+d.getUTCDate()+' '+MON[d.getUTCMonth()];}
function fmtLong(s){var d=new Date(s+'T00:00:00Z');return DOWL[d.getUTCDay()]+', '+d.getUTCDate()+' '+MONL[d.getUTCMonth()];}
function relDay(s){var n=diffDays(todayStr(),s);return n===0?'Today':n===1?'Tomorrow':n===-1?'Yesterday':fmtShort(s);}
function clockIn(tz){return new Date().toLocaleTimeString('en-US',{timeZone:tz,hour:'numeric',minute:'2-digit'});}
function tsTime(ts,tz){return new Date(ts).toLocaleTimeString('en-US',{timeZone:tz,hour:'numeric',minute:'2-digit'});}
function toMin(hm){if(!hm)return 1440;var a=hm.split(':');return (+a[0])*60+(+a[1]);}
function fmtTime(hm){var a=hm.split(':');var h=+a[0];var ap=h>=12?'PM':'AM';h=h%12||12;return h+':'+a[1]+' '+ap;}
function fmtMin(m){m=Math.round(m||0);if(m<60)return m+'m';var h=Math.floor(m/60),r=m%60;return r?h+'h '+r+'m':h+'h';}
function fmtAx(v){if(v===0)return '0';if(v<60)return v+'m';var h=v/60;return (h%1===0?h:h.toFixed(1))+'h';}
function tsC(d,hm){return Date.parse(d+'T'+hm+':00+05:30');}
function clampInt(v,lo,hi){var n=parseInt(v,10);if(isNaN(n))return 0;return Math.max(lo,Math.min(hi,n));}

/* ---------- vocabulary ---------- */
var CAT={school:{l:'School',i:'school',c:'school'},study:{l:'Study',i:'pencil',c:'study'},reading:{l:'Reading',i:'book',c:'read'},active:{l:'Sports & outdoor',i:'ball',c:'active'},creative:{l:'Creative',i:'palette',c:'create'},family:{l:'Family call',i:'video',c:'family'},meal:{l:'Meal',i:'meal',c:'life'},rest:{l:'Rest',i:'moon',c:'life'},free:{l:'Free time',i:'leaf',c:'life'},routine:{l:'Routine',i:'clock',c:'life'},sleep:{l:'Bedtime',i:'moon',c:'life'}};
var KINDS={sports:{l:'Sports practice',i:'ball'},exercise:{l:'Exercise',i:'flame'},outdoor:{l:'Outdoor play',i:'today'},creative:{l:'Creative',i:'palette'},screenfree:{l:'Screen-free time',i:'leaf'}};
var MOODS={happy:'Happy',okay:'Okay',tired:'Tired',sad:'Sad',frustrated:'Frustrated'};
var SUBJECTS=['Maths','Science','English','Hindi','Social Science','Gujarati','Sanskrit','Computer','GK','Other'];
var SCHOOL={name:'Mount Litera Zee School, Porbandar',grade:'6A',url:'https://epfuture.mountlitera.com/pages/StudentClasswork.aspx?page=2'};
var PERIODS=[['08:10','08:55'],['08:55','09:40'],['09:40','10:25'],['10:25','11:10'],['11:30','12:15'],['12:15','13:00'],['13:00','13:45']];
var ROMAN=['I','II','III','IV','V','VI','VII'];
function isSchoolDay(w){return w>=1&&w<=6;}
function isHoliday(d){return !!(state&&state.holidays&&state.holidays[d]);}
function isSchoolDate(d){return isSchoolDay(wd(d))&&!isHoliday(d);}
function subjOfPeriod(p){p=String(p||'');if(/social/i.test(p))return 'Social Science';if(/science/i.test(p))return 'Science';if(/math/i.test(p))return 'Maths';if(/english/i.test(p))return 'English';if(/hindi/i.test(p))return 'Hindi';if(/guj/i.test(p))return 'Gujarati';if(/sans/i.test(p))return 'Sanskrit';if(/computer/i.test(p))return 'Computer';if(/^gk$/i.test(p.trim()))return 'GK';return null;}
function schoolLink(cls,label){return '<a class="'+cls+'" href="'+SCHOOL.url+'" target="_blank" rel="noopener noreferrer">'+ic('ext')+(label||'School homework')+'</a>';}
function curPeriod(d){if(d!==todayStr()||!isSchoolDate(d))return null;var m=nowMin();for(var i=0;i<PERIODS.length;i++){if(toMin(PERIODS[i][0])<=m&&m<toMin(PERIODS[i][1]))return {i:i,subj:(state.timetable[wd(d)]||[])[i]||'',end:PERIODS[i][1]};}if(m>=toMin('11:10')&&m<toMin('11:30'))return {i:-1,subj:'Break',end:'11:30'};return null;}
var TASKCAT={homework:'Homework',chore:'Chore',personal:'Personal'};
var STAMPS={welldone:'Well done',proud:'Proud of you',keepgoing:'Keep going',shabash:'Shabash!'};
var EXAMKINDS=['Unit test','Periodic test','Class test','Dictation','Half-yearly exam','Annual exam'];

/* ---------- defaults ---------- */
function templates(){
  var n=0;function b(start,end,title,cat){n++;return {id:'t'+n,start:start,end:end,title:title,cat:cat};}
  return {
    school:[b('06:45','07:15','Wake up and get ready','routine'),b('07:30','14:30','School','school'),b('14:30','15:00','Freshen up and lunch, no screens','meal'),b('15:00','15:30','TV and relax','free'),b('15:30','16:30','Homework and study','study'),b('16:30','16:50','Snack break','meal'),b('16:50','17:20','Reading time','reading'),b('17:30','19:00','Tuition','school'),b('19:00','20:00','Outdoor play','active'),b('20:00','21:00','TV and dinner','meal'),b('21:00','21:30','Bath and brush','routine'),b('21:30','22:00','Call with {P}','family'),b('22:30','','Sleep','sleep')],
    weekend:[b('07:30','08:00','Wake up','routine'),b('08:00','08:30','Breakfast','meal'),b('09:00','10:30','Cricket coaching or outdoor play','active'),b('11:00','12:00','Revision','study'),b('12:00','13:00','Creative time','creative'),b('13:00','13:45','Lunch','meal'),b('14:00','15:00','Rest','rest'),b('16:00','16:45','Reading time','reading'),b('17:00','18:30','Play outside','active'),b('19:00','20:00','Family time','free'),b('20:00','20:30','Dinner','meal'),b('20:30','21:15','Video call with {P}','family'),b('21:45','','Bedtime','sleep')]
  };
}
function timetable(){return {
  1:['Science','Hindi','Maths','Art','Hindi','Science','Science'],
  2:['PE','Social Science','Social Science','English (Grammar)','Library','English (Grammar)','English (Grammar)'],
  3:['Hindi','Computer','Computer','Gujarati/Sanskrit','Maths','Gujarati/Sanskrit','Maths'],
  4:['Science','Science','Hindi','Hindi','PE','Hindi','Flip/DCP'],
  5:['Maths','GK','Music/Art','English (Lit)','Social Science','Maths','Maths'],
  6:['Social Science','English (Lit)','English (Lit)','Social Science','Karate','Karate','Social Science']};}
/* ---------- state ---------- */
var state=null, me=null, ui={mode:'child',tab:{child:'today',parent:'overview'},planDay:null,pday:0,sheet:null,toast:null,screen:'loading',auth:{role:null,mode:'signin'},setupStep:1};
function blankState(){
  return {family:{child:'',parent:''},goals:{study:360,reading:210,active:420},template:templates(),timetable:timetable(),plans:{},tasks:[],logs:[],books:[],exams:[],moods:{},messages:[],rewards:[],redemptions:[],notify:{reward:true,exam:true,mood:true,milestone:true,weekly:true,screen:true},screen:{limit:{school:120,weekend:180},days:{}},holidays:{}};
}
function defaultRewards(){return [{id:'r1',title:'Choose the Friday movie',cost:100},{id:'r2',title:'Extra 30 minutes of cycling',cost:60},{id:'r3',title:'Game night on our video call',cost:150},{id:'r4',title:'A new book of my choice',cost:250},{id:'r5',title:'Pizza night with Granny and Granu',cost:400}];}
function loadUI(){try{var raw=localStorage.getItem(UIKEY);if(raw){var p=JSON.parse(raw);if(p.tab)ui.tab=Object.assign(ui.tab,p.tab);}}catch(e){}}
function saveUI(){try{localStorage.setItem(UIKEY,JSON.stringify({tab:ui.tab}));}catch(e){}}
function dismissed(k){try{return localStorage.getItem('gc-dismiss-'+k)==='1';}catch(e){return false;}}
function setDismissed(k){try{localStorage.setItem('gc-dismiss-'+k,'1');}catch(e){}}
function P(){return (state&&state.family.parent)||'your parent';}
function C(){return (state&&state.family.child)||'your child';}
function tt(s){return String(s).replace(/\{P\}/g,P());}

/* ---------- sync ---------- */
var KNOWN=['family','routine','parentcfg','notify','task','log','book','exam','message','reward','redemption','plan','holiday','mood','private','screen'];
var server={},saving=0,saveFailed=false,retryTimer=null,pendingRender=false,lastRefresh=0;
function canon(v){
  if(v===null||v===undefined||typeof v!=='object')return JSON.stringify(v===undefined?null:v);
  if(Array.isArray(v))return '['+v.map(canon).join(',')+']';
  return '{'+Object.keys(v).filter(function(k){return v[k]!==undefined;}).sort().map(function(k){return JSON.stringify(k)+':'+canon(v[k]);}).join(',')+'}';
}
function clone(v){return JSON.parse(JSON.stringify(v));}
function writable(kind,key){
  if(!me||!me.role||KNOWN.indexOf(kind)<0)return false;
  if(me.role==='child')return ['family','parentcfg','reward','notify'].indexOf(kind)<0;
  return kind!=='private'&&(kind!=='notify'||key===me.userId);
}
function toRows(){
  var rows={};
  function put(kind,key,data){rows[kind+'|'+key]={kind:kind,key:String(key),data:data};}
  put('family','names',{child:state.family.child||'',parent:state.family.parent||''});
  put('routine','main',{template:state.template,timetable:state.timetable});
  put('parentcfg','main',{goals:state.goals,screenLimit:state.screen.limit});
  if(me&&me.role==='parent')put('notify',me.userId,state.notify);
  [['task','tasks'],['log','logs'],['book','books'],['exam','exams'],['message','messages'],['reward','rewards'],['redemption','redemptions']].forEach(function(p){
    state[p[1]].forEach(function(x){put(p[0],x.id,x);});
  });
  Object.keys(state.plans).forEach(function(d){put('plan',d,{blocks:state.plans[d]});});
  Object.keys(state.holidays).forEach(function(d){if(state.holidays[d])put('holiday',d,{on:true});});
  Object.keys(state.moods).forEach(function(d){
    var m=state.moods[d];
    put('mood',d,{face:m.face,share:!!m.share,note:m.share?(m.note||''):'',ts:m.ts||0});
    if(me&&me.role==='child'&&!m.share&&m.note)put('private','mood:'+d,{note:m.note});
  });
  Object.keys(state.screen.days).forEach(function(d){put('screen',d,state.screen.days[d]);});
  return rows;
}
function fromRows(map){
  var s=blankState(),names=null,priv={};
  Object.keys(map).forEach(function(k){
    var r=map[k],d=clone(r.data||{});
    switch(r.kind){
    case 'family':names=d;break;
    case 'routine':if(d.template)s.template=d.template;if(d.timetable)s.timetable=d.timetable;break;
    case 'parentcfg':if(d.goals)s.goals=d.goals;if(d.screenLimit)s.screen.limit=d.screenLimit;break;
    case 'notify':if(me&&r.key===me.userId)s.notify=Object.assign(s.notify,d);break;
    case 'task':s.tasks.push(d);break;
    case 'log':s.logs.push(d);break;
    case 'book':s.books.push(d);break;
    case 'exam':s.exams.push(d);break;
    case 'message':s.messages.push(d);break;
    case 'reward':s.rewards.push(d);break;
    case 'redemption':s.redemptions.push(d);break;
    case 'plan':s.plans[r.key]=d.blocks||[];break;
    case 'holiday':s.holidays[r.key]=true;break;
    case 'mood':s.moods[r.key]={face:d.face,share:!!d.share,note:d.note||'',ts:d.ts||0};break;
    case 'private':if(r.key.indexOf('mood:')===0)priv[r.key.slice(5)]=d.note||'';break;
    case 'screen':s.screen.days[r.key]=d;break;
    }
  });
  if(names)s.family={child:names.child||'',parent:names.parent||''};
  Object.keys(priv).forEach(function(d){var m=s.moods[d];if(m&&!m.share)m.note=priv[d];});
  function byTs(a,b){return (a.ts||0)-(b.ts||0)||String(a.id).localeCompare(String(b.id));}
  s.tasks.sort(byTs);s.logs.sort(byTs);s.books.sort(byTs);s.messages.sort(byTs);s.redemptions.sort(byTs);
  s.rewards.sort(function(a,b){return (a.cost||0)-(b.cost||0);});
  return s;
}
function friendly(e){
  var m=(e&&(e.message||e.error_description||e.msg))||String(e||'');
  if(!navigator.onLine||/failed to fetch|load failed|network|fetch/i.test(m))return 'No internet right now. Your change will save when you’re back online.';
  if(/row-level security|permission denied|not allowed|42501/i.test(m))return 'That change isn’t allowed.';
  return m||'Something went wrong. Try again.';
}
function isNetErr(e){var m=(e&&e.message)||String(e||'');return !navigator.onLine||/failed to fetch|load failed|network|fetch/i.test(m);}
function setSync(){document.documentElement.setAttribute('data-sync',saveFailed?'offline':saving?'saving':'ok');}
function save(){
  if(!me||!me.familyId||!state)return;
  var local=toRows(),ups=[],dels=[],backup={};
  Object.keys(local).forEach(function(k){
    var r=local[k];if(!writable(r.kind,r.key))return;
    var c=canon(r.data);
    if(!server[k]||server[k].c!==c){backup[k]=server[k]||null;ups.push({kind:r.kind,key:r.key,data:clone(r.data)});server[k]={kind:r.kind,key:r.key,data:clone(r.data),c:c};}
  });
  Object.keys(server).forEach(function(k){
    if(local[k])return;var r=server[k];if(!writable(r.kind,r.key))return;
    backup[k]=r;dels.push({kind:r.kind,key:r.key});delete server[k];
  });
  if(!ups.length&&!dels.length)return;
  saving++;setSync();
  Promise.all([ups.length?API.upsert(me.familyId,ups):null,dels.length?API.remove(me.familyId,dels):null]).then(function(){
    saving--;var was=saveFailed;saveFailed=false;setSync();
    if(was)refresh().then(softRender).catch(function(){});
  }).catch(function(err){
    saving--;
    Object.keys(backup).forEach(function(k){if(backup[k])server[k]=backup[k];else delete server[k];});
    if(isNetErr(err)){
      saveFailed=true;setSync();toast(friendly(err));
      clearTimeout(retryTimer);retryTimer=setTimeout(save,8000);
    }else{
      setSync();toast(friendly(err));
      refresh().then(softRender).catch(function(){});
    }
  });
}
async function refresh(){
  if(!me||!me.familyId)return;
  if(saveFailed){save();return;}
  var rows=await API.loadItems(me.familyId),map={};
  rows.forEach(function(r){map[r.kind+'|'+r.key]={kind:r.kind,key:r.key,data:r.data,c:canon(r.data)};});
  server=map;state=fromRows(server);lastRefresh=Date.now();
}
function applyRemote(ev,row){
  if(!row||!row.kind)return;
  var k=row.kind+'|'+row.key;
  if(ev==='DELETE'){if(!server[k])return;delete server[k];}
  else{var c=canon(row.data);if(server[k]&&server[k].c===c)return;server[k]={kind:row.kind,key:row.key,data:row.data,c:c};}
  if(saveFailed)return;
  state=fromRows(server);softRender();
}
function typingIn(sel){var a=document.activeElement;return !!(a&&a.closest&&a.closest(sel)&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName));}
function softRender(){
  if(ui.screen!=='app')return;
  if(typingIn('#app')){pendingRender=true;return;}
  render();
  if(ui.sheet&&ui.sheet.s==='messages'&&!typingIn('#sheet-root')){var ta=$('#cm-text'),v=ta?ta.value:'';renderSheet();var tb=$('#cm-text');if(tb&&v)tb.value=v;}
}
document.addEventListener('focusout',function(){setTimeout(function(){if(pendingRender&&!typingIn('#app')){pendingRender=false;render();}},60);});
window.addEventListener('online',function(){if(saveFailed)save();else if(ui.screen==='app')refresh().then(softRender).catch(function(){});});
document.addEventListener('visibilitychange',function(){
  if(document.visibilityState==='visible'&&ui.screen==='app'&&!saving&&Date.now()-lastRefresh>20000){refresh().then(softRender).catch(function(){});checkPush();}
});

/* ---------- derived ---------- */
function getPlan(d){if(state.plans[d])return state.plans[d];var tpl=isSchoolDate(d)?state.template.school:state.template.weekend;return tpl.map(function(b){return Object.assign({},b);});}
function sortPlan(p){return p.slice().sort(function(a,b){return a.start.localeCompare(b.start);});}
function editPlan(d){if(!state.plans[d])state.plans[d]=getPlan(d);return state.plans[d];}
function inBlock(b,m){return toMin(b.start)<=m&&m<toMin(b.end);}
function nowNext(d){var p=sortPlan(getPlan(d)),m=nowMin();var cur=null,next=null;for(var i=0;i<p.length;i++){if(inBlock(p[i],m))cur=p[i];if(!next&&toMin(p[i].start)>m)next=p[i];}return {cur:cur,next:next,first:p[0]};}
function logsOn(d,type){return state.logs.filter(function(l){return l.date===d&&(!type||l.type===type);});}
function minOn(d,type){return sum(logsOn(d,type),function(l){return l.min;});}
function rangeDays(from,n){var a=[];for(var i=0;i<(n||7);i++)a.push(addDays(from,i));return a;}
function totals(days){var t={study:0,reading:0,activity:0,pages:0};state.logs.forEach(function(l){if(days.indexOf(l.date)>-1){t[l.type]+=l.min||0;if(l.type==='reading')t.pages+=l.pages||0;}});return t;}
function has(d,type){return state.logs.some(function(l){return l.date===d&&l.type===type;});}
function checkedIn(d){return !!state.moods[d]||logsOn(d).length>0;}
function streak(pred){var d=todayStr(),n=0;if(!pred(d))d=addDays(d,-1);var g=0;while(pred(d)&&g<500){n++;d=addDays(d,-1);g++;}return n;}
function bestStreak(pred){var best=0,cur=0,T=todayStr();for(var i=90;i>=0;i--){if(pred(addDays(T,-i))){cur++;if(cur>best)best=cur;}else cur=0;}return best;}
function logPts(l){if(l.type==='study')return 10+(l.min>=45?5:0);if(l.type==='reading')return 10+(l.note?5:0);return 10;}
function scrDay(d){return (state.screen&&state.screen.days[d])||null;}
function scrTotal(d){var x=scrDay(d);return x?(+x.min||0):0;}
function scrLimit(d){return isSchoolDate(d)?state.screen.limit.school:state.screen.limit.weekend;}
function scrOk(d){return d<todayStr()&&!!scrDay(d)&&scrTotal(d)<=scrLimit(d);}
function earned(){var p=0;if(state.screen)Object.keys(state.screen.days).forEach(function(d){if(scrOk(d))p+=10;});state.tasks.forEach(function(t){if(t.done)p+=5;});state.logs.forEach(function(l){p+=logPts(l);});return p+Object.keys(state.moods).length*2;}
function held(){return sum(state.redemptions.filter(function(r){return r.status!=='declined';}),function(r){return r.cost;});}
function balance(){return earned()-held();}
function bookById(id){for(var i=0;i<state.books.length;i++)if(state.books[i].id===id)return state.books[i];return null;}
function aim(weekly){return Math.max(5,Math.round(weekly/7/5)*5);}
function unread(from){return state.messages.filter(function(m){return m.from===from&&!m.read;}).length;}
function stampList(){
  var T=todayStr(),days=rangeDays(addDays(T,-6));
  var rb=bestStreak(function(d){return has(d,'reading');});
  var pages=sum(state.logs.filter(function(l){return l.type==='reading';}),function(l){return l.pages;});
  var hw=state.tasks.filter(function(t){return t.done&&t.cat==='homework';}).length;
  var act=totals(days).activity;
  var sd=days.filter(function(d){return has(d,'study');}).length;
  var mc=Object.keys(state.moods).length;
  var fin=state.books.filter(function(b){return b.read>=b.total;}).length;
  return [
    {id:'bookworm',name:'Bookworm',desc:'Read 5 days in a row',got:rb>=5,i:'book',p:Math.min(rb,5)+' of 5 days'},
    {id:'pages',name:'100 Pages',desc:'Read 100 pages',got:pages>=100,i:'star',p:Math.min(pages,100)+' of 100'},
    {id:'finisher',name:'Book Finisher',desc:'Finish a whole book',got:fin>=1,i:'check',p:fin+' finished'},
    {id:'hero',name:'Homework Hero',desc:'Finish 10 homework tasks',got:hw>=10,i:'pencil',p:Math.min(hw,10)+' of 10'},
    {id:'outabout',name:'Out & About',desc:'5 hours active in 7 days',got:act>=300,i:'ball',p:fmtMin(Math.min(act,300))+' of 5h'},
    {id:'steady',name:'Steady Learner',desc:'Study 5 of the last 7 days',got:sd>=5,i:'target',p:Math.min(sd,5)+' of 5 days'},
    {id:'feelings',name:'Feelings Friend',desc:'Check in your mood 7 times',got:mc>=7,i:'heart',p:Math.min(mc,7)+' of 7'},
    {id:'screensmart',name:'Screen Smart',desc:'5 days in a row within screen time',got:bestStreak(scrOk)>=5,i:'tablet',p:Math.min(bestStreak(scrOk),5)+' of 5 days'},
    {id:'giver',name:'Family Helper',desc:'Finish 10 chores',got:state.tasks.filter(function(t){return t.done&&t.cat==='chore';}).length>=10,i:'home',p:Math.min(state.tasks.filter(function(t){return t.done&&t.cat==='chore';}).length,10)+' of 10'}
  ];
}

/* ---------- say it: turn a spoken sentence into logs ---------- */
var NUMW=[['forty five',45],['forty-five',45],['twenty five',25],['twenty-five',25],['thirty five',35],['one',1],['two',2],['three',3],['four',4],['five',5],['six',6],['seven',7],['eight',8],['nine',9],['ten',10],['eleven',11],['twelve',12],['fifteen',15],['twenty',20],['thirty',30],['forty',40],['fifty',50],['sixty',60],['ninety',90]];
var SUBJ_W=[[/\bmaths?\b|\bmathematics\b/i,'Maths'],[/\bscience\b/i,'Science'],[/\benglish\b|\bgrammar\b|\bspellings?\b/i,'English'],[/\bhindi\b/i,'Hindi'],[/\bsocial\b|\bsst\b|\bhistory\b|\bgeography\b|\bcivics\b/i,'Social Science'],[/\bgujarati\b/i,'Gujarati'],[/\bsanskrit\b/i,'Sanskrit'],[/\bgk\b|\bgeneral knowledge\b/i,'GK'],[/\bcomputers?\b|\btyping\b/i,'Computer']];
var ACT_W=[[/\bcricket\b/i,'Cricket','sports'],[/\bfootball\b|\bsoccer\b/i,'Football','sports'],[/\bbadminton\b/i,'Badminton','sports'],[/\btennis\b/i,'Tennis','sports'],[/\bswim/i,'Swimming','sports'],[/\bbasketball\b/i,'Basketball','sports'],[/\bskat/i,'Skating','sports'],[/\bkarate\b|\btaekwondo\b/i,'Karate','sports'],[/\byoga\b/i,'Yoga','exercise'],[/\bskipping\b|\bjump rope\b/i,'Skipping','exercise'],[/\bran\b|\brun(ning)?\b|\bjog/i,'Running','exercise'],[/\bexercise|\bworkout\b|\bpush ?ups?\b/i,'Exercise','exercise'],[/\bwalk/i,'Walk','exercise'],[/\bcycl|\bbike\b|\bbicycle\b/i,'Cycling','outdoor'],[/\bdr(ew|aw|awing)\b|\bpaint|\bcolou?r(ed|ing)\b/i,'Drawing','creative'],[/\bharmonium\b|\bguitar\b|\bpiano\b|\bmusic\b|\bsing(ing)?\b|\bsang\b/i,'Music practice','creative'],[/\bdanc/i,'Dance','creative'],[/\bclay\b|\bcraft|\blego\b|\bbuilt\b|\bbuild/i,'Craft and building','creative'],[/\bcarrom\b|\bchess\b|\bboard games?\b|\bpuzzle|\bcards\b|\bludo\b/i,'Board games','screenfree'],[/\bgarden\b|\bpark\b|\boutside\b|\boutdoors?\b/i,'Outdoor play','outdoor'],[/\bplay(ed|ing)?\b/i,'Play','outdoor']];
var STUDY_W=/\bhomework\b|\bstud(y|ied|ying)\b|\brevis|\btuition\b|\bworksheet\b/i;
function normNums(s){
  s=s.replace(/\b(an?|one) hour and a half\b|\bone and a half hours?\b/gi,'90 minutes').replace(/\bhalf an hour\b|\bhalf[- ]hour\b/gi,'30 minutes').replace(/\bquarter of an hour\b/gi,'15 minutes').replace(/\b(an|a) hour\b/gi,'60 minutes');
  NUMW.forEach(function(p){s=s.replace(new RegExp('\\b'+p[0]+'\\b','gi'),String(p[1]));});
  return s;
}
function getMin(s){var t=0,f=false,m,re=/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/gi;while((m=re.exec(s))){t+=Math.round(parseFloat(m[1])*60);f=true;}re=/(\d+)\s*(?:minutes?|mins?)\b/gi;while((m=re.exec(s))){t+=+m[1];f=true;}return f?t:0;}
function getPages(s){var m=s.match(/pages?\s*(\d+)\s*(?:to|-|till|until)\s*(\d+)/i);if(m)return Math.max(1,(+m[2])-(+m[1]));m=s.match(/(\d+)\s*pages?\b/i);return m?+m[1]:0;}
function findBook(s){var low=s.toLowerCase();var bs=state.books.slice().sort(function(a,b){return (a.read>=a.total)-(b.read>=b.total);});for(var i=0;i<bs.length;i++){var t=bs[i].title.toLowerCase();if(low.indexOf(t)>-1)return bs[i];var ws=t.split(/\s+/).filter(function(w){return w.length>=5;});for(var j=0;j<ws.length;j++)if(low.indexOf(ws[j])>-1)return bs[i];}return null;}
function subjOf(s){for(var i=0;i<SUBJ_W.length;i++)if(SUBJ_W[i][0].test(s))return SUBJ_W[i][1];return null;}
function actOf(s){for(var i=0;i<ACT_W.length;i++)if(ACT_W[i][0].test(s))return ACT_W[i];return null;}
function detect(s){
  if(findBook(s))return 'reading';
  var sub=subjOf(s);
  if(sub||STUDY_W.test(s))return 'study';
  if(/\bread\b|\breading\b|\bbooks?\b|\bpages?\b/i.test(s))return 'reading';
  if(actOf(s))return 'activity';
  return null;
}
function segments(text){
  var out=[];
  text.split(/[.;!?\n]+|\bthen\b|\bafter that\b|\balso\b/i).forEach(function(part){
    part=part.trim();if(!part)return;
    var cur='';
    part.split(/\band\b|,/i).forEach(function(b){
      b=b.trim();if(!b)return;
      if(cur){var t1=detect(cur),t2=detect(b);if(t1&&t2&&(t1!==t2||(getMin(cur)&&getMin(b)))){out.push(cur);cur=b;}else cur=cur+' and '+b;}
      else cur=b;
    });
    if(cur){if(!detect(cur)&&out.length)out[out.length-1]+='. '+cur;else out.push(cur);}
  });
  return out.filter(detect);
}
function cap(s){s=String(s||'').trim();return s?s.charAt(0).toUpperCase()+s.slice(1):'';}
function parseSeg(seg){
  var type=detect(seg),min=getMin(seg);
  if(type==='study'){
    var hw=/homework\s+(?:is|was)?\s*(?:done|finished|complete)|(?:finished|completed|did|done with)\s+(?:my|the|all)?\s*homework/i.test(seg);
    var topic=seg.replace(/\bfor\s+\d+(?:\.\d+)?\s*(?:hours?|hrs?|minutes?|mins?)\b/gi,' ').replace(/\d+(?:\.\d+)?\s*(?:hours?|hrs?|minutes?|mins?)\b/gi,' ');
    SUBJ_W.forEach(function(w){topic=topic.replace(new RegExp(w[0].source,'gi'),' ');});
    topic=topic.replace(/\b(i|me|my|the|a|an|and|did|do|have|has|had|was|is|some|for|of|on|about|today|yesterday|studied|study|studying|homework|done|finished|completed|complete|revised|revision|revising|practised|practiced|practice|learnt|learned|worked|work|at|in|with|then)\b/gi,' ').replace(/[,.]/g,' ').replace(/\s+/g,' ').trim();
    return {type:'study',subject:subjOf(seg)||'Other',min:min,topic:cap(topic).slice(0,60),hw:hw};
  }
  if(type==='reading'){
    var b=findBook(seg),cur=state.books.filter(function(x){return x.read<x.total;})[0]||state.books[0]||null;
    var nm=seg.match(/\b(?:i\s+)?(?:liked|loved|learn(?:ed|t)|it was about|the story is about|my favou?rite part|i think)\b.*$/i);
    return {type:'reading',bookId:(b||cur||{}).id||'',pages:getPages(seg),min:min,note:nm?cap(nm[0]).slice(0,200):''};
  }
  var a=actOf(seg),what=a?a[1]:'Play';
  if(a&&a[2]==='sports'&&/practi[cs]/i.test(seg))what+=' practice';
  return {type:'activity',kind:a?a[2]:'outdoor',what:what,min:min};
}
function parseSpeech(text){return segments(normNums(text)).map(parseSeg);}
function remindText(r){if(!r||!r.length)return 'No reminders';var L={7:'a week',3:'3 days',1:'1 day',0:'on the day'};return 'Reminders: '+r.slice().sort(function(a,b){return b-a;}).map(function(x){return L[x];}).join(', ');}

/* ---------- drawing ---------- */
function faceInner(m){
  var dot=(m!=='tired');
  var eyes=dot?'<circle cx="14" cy="17" r="2.2" style="fill:var(--face-ink)"/><circle cx="26" cy="17" r="2.2" style="fill:var(--face-ink)"/>':'';
  var lines='';
  if(m==='tired')lines+='<path d="M11.5 17.2q2.5 2.3 5 0M23.5 17.2q2.5 2.3 5 0"/>';
  if(m==='frustrated')lines+='<path d="M10.5 11.5l6 2.6M29.5 11.5l-6 2.6"/>';
  if(m==='sad')lines+='<path d="M11 13.8l5-2M29 13.8l-5-2"/>';
  var mouth={happy:'M12.5 24q7.5 8 15 0',okay:'M14.5 26.5h11',tired:'M17 27.5q3-2.6 6 0',sad:'M13 29.5q7-6.5 14 0',frustrated:'M13.5 27.5q2.2-2.2 4.4 0t4.4 0t4.4 0'}[m]||'M14.5 26.5h11';
  return '<circle cx="20" cy="20" r="18.5" style="fill:var(--m-'+m+')"/>'+eyes+'<g style="fill:none;stroke:var(--face-ink)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'+lines+'<path d="'+mouth+'"/></g>';
}
function face(m,size){return '<svg width="'+size+'" height="'+size+'" viewBox="0 0 40 40" aria-hidden="true" focusable="false">'+faceInner(m)+'</svg>';}
function stampSVG(s){
  var label=(s.name.length<=10?(s.name+' • ')+(s.name+' • '):(s.name+' • ')).toUpperCase();
  var pid='sp-'+s.id;
  return '<svg viewBox="0 0 100 100" aria-hidden="true" focusable="false"><defs><path id="'+pid+'" d="M50,50 m-30,0 a30,30 0 1,1 60,0 a30,30 0 1,1 -60,0"/></defs>'+
    '<circle cx="50" cy="50" r="45" style="fill:none;stroke:currentColor" stroke-width="3"/>'+
    '<circle cx="50" cy="50" r="39" style="fill:none;stroke:currentColor" stroke-width="1.2" stroke-dasharray="'+(s.got?'0':'3 3')+'"/>'+
    '<text class="stamp-t"><textPath href="#'+pid+'" textLength="184" lengthAdjust="spacing">'+esc(label)+'</textPath></text>'+
    '<g transform="translate(37 37) scale(1.08)" style="fill:none;stroke:currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+(IC[s.i]||'')+'</g></svg>';
}
function chart(days){
  var W=320,L=30,R=6,TP=10,PH=116,base=TP+PH,H=base+44;
  var T=todayStr();
  var data=days.map(function(d){return {d:d,s:minOn(d,'study'),r:minOn(d,'reading'),a:minOn(d,'activity'),m:state.moods[d]&&state.moods[d].face};});
  var mx=60;data.forEach(function(x){mx=Math.max(mx,x.s+x.r+x.a);});
  var top=Math.ceil(mx/60)*60;
  var cw=(W-L-R)/7,bw=Math.min(20,cw*.55);
  function y(v){return base-v/top*PH;}
  var g='';
  [0,top/2,top].forEach(function(v){g+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v).toFixed(1)+'" y2="'+y(v).toFixed(1)+'" class="gl"/><text x="'+(L-6)+'" y="'+(y(v)+3.5).toFixed(1)+'" class="ax" text-anchor="end">'+fmtAx(v)+'</text>';});
  data.forEach(function(x,i){
    var cx=L+cw*i+cw/2,acc=0;
    [['s','study'],['r','read'],['a','active']].forEach(function(p){var v=x[p[0]];if(!v)return;var y0=y(acc),y1=y(acc+v);g+='<rect x="'+(cx-bw/2).toFixed(1)+'" y="'+y1.toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+Math.max(1,y0-y1-1.5).toFixed(1)+'" rx="2.5" style="fill:var(--c-'+p[1]+')"/>';acc+=v;});
    g+='<text x="'+cx.toFixed(1)+'" y="'+(base+15)+'" class="ax'+(x.d===T?' axb':'')+'" text-anchor="middle">'+(x.d===T?'Today':DOW[wd(x.d)])+'</text>';
    if(x.m)g+='<g transform="translate('+(cx-8).toFixed(1)+' '+(base+22)+') scale(.4)">'+faceInner(x.m)+'</g>';
    else g+='<circle cx="'+cx.toFixed(1)+'" cy="'+(base+30)+'" r="2.5" class="nodot"/>';
  });
  return '<div class="chart"><svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Minutes of study, reading and sports for each of the last 7 days, with the mood check-in under each day">'+g+'</svg></div>'+
    '<div class="legend"><span class="cat-study"><i></i>Study</span><span class="cat-read"><i></i>Reading</span><span class="cat-active"><i></i>Sports &amp; screen-free</span><span>'+face('happy',12)+' Mood check-in</span></div>';
}

/* ---------- screen time ---------- */
function scrWeekChart(days){
  var W=320,L=30,R=6,TP=10,PH=110,base=TP+PH,H=base+22,T=todayStr();
  var data=days.map(function(d){return {d:d,has:!!scrDay(d),t:scrTotal(d),lim:scrLimit(d)};});
  var mx=60;data.forEach(function(x){mx=Math.max(mx,x.t,x.lim);});var top=Math.ceil(mx/60)*60;
  var cw=(W-L-R)/7,bw=Math.min(22,cw*.55);function y(v){return base-v/top*PH;}
  var g='';
  [0,top/2,top].forEach(function(v){g+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v).toFixed(1)+'" y2="'+y(v).toFixed(1)+'" class="gl"/><text x="'+(L-6)+'" y="'+(y(v)+3.5).toFixed(1)+'" class="ax" text-anchor="end">'+fmtAx(v)+'</text>';});
  data.forEach(function(x,i){
    var cx=L+cw*i+cw/2,inn=Math.min(x.t,x.lim),ov=Math.max(0,x.t-x.lim);
    if(!x.has)g+='<circle cx="'+cx.toFixed(1)+'" cy="'+(base-4)+'" r="2.5" class="nodot"/>';
    if(inn)g+='<rect x="'+(cx-bw/2).toFixed(1)+'" y="'+y(inn).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+(base-y(inn)).toFixed(1)+'" rx="2.5" style="fill:var(--c-screen)"/>';
    if(ov)g+='<rect x="'+(cx-bw/2).toFixed(1)+'" y="'+y(x.t).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+Math.max(1,y(inn)-y(x.t)-1.5).toFixed(1)+'" rx="2.5" style="fill:var(--margin)"/>';
    g+='<line x1="'+(cx-bw/2-4).toFixed(1)+'" x2="'+(cx+bw/2+4).toFixed(1)+'" y1="'+y(x.lim).toFixed(1)+'" y2="'+y(x.lim).toFixed(1)+'" class="ltick"/>';
    g+='<text x="'+cx.toFixed(1)+'" y="'+(base+15)+'" class="ax'+(x.d===T?' axb':'')+'" text-anchor="middle">'+(x.d===T?'Today':DOW[wd(x.d)])+'</text>';
  });
  return '<div class="chart"><svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="iPad screen time for each of the last 7 days against the daily limit">'+g+'</svg></div><div class="legend"><span class="cat-screen"><i></i>Within limit</span><span><i class="overk"></i>Over limit</span><span><i class="dash"></i>Daily limit</span><span><i class="dotk"></i>Not added</span></div>';
}
function screenHow(viewer){
  return viewer==='child'
    ?'On your iPad: <b>Settings → Screen Time → See All App &amp; Website Activity</b>. Add the total for the day.'
    :'See the exact number on your iPhone: <b>Settings → Screen Time → '+esc(C())+'</b>.';
}
function limitText(d){return fmtMin(scrLimit(d))+(isSchoolDate(d)?' on school days':isHoliday(d)?' on holidays':' on Sundays');}
function screenCard(d,viewer){
  var T=todayStr(),x=scrDay(d),lim=scrLimit(d);
  var head=viewer==='child'?'My screen time':'iPad screen time';
  if(!x){
    var msg=viewer==='child'?(d===T?'Add today’s total before bed.':'Not added for this day.'):(esc(C())+' hasn’t added screen time for '+(d===T?'today':'this day')+' yet.');
    return '<section class="card cat-screen"><div class="card-h"><h2>'+head+'</h2><span class="muted">Limit '+fmtMin(lim)+'</span></div><p class="empty">'+msg+'</p><button class="btn ghost wide" data-act="sheet" data-s="screen" data-d="'+d+'">'+ic('tablet')+'Add screen time</button><p class="hint">'+ic('tablet','lockc')+'<span>'+screenHow(viewer)+'</span></p></section>';
  }
  var tot=scrTotal(d),over=tot-lim,pct=Math.min(100,Math.round(tot/lim*100));
  var st=over>0?'<span class="pill over">Over by '+fmtMin(over)+'</span>':'<span class="pill good">'+ic('check')+'Within limit</span>';
  var out='<section class="card cat-screen"><div class="card-h"><h2>'+head+'</h2><button class="tiny" data-act="sheet" data-s="screen" data-d="'+d+'">Edit</button></div>'+
    '<div class="scr-big"><b>'+fmtMin(tot)+'</b><span>of '+limitText(d)+'</span>'+st+'</div>'+
    '<span class="bar'+(over>0?' over':'')+'" role="progressbar" aria-label="Screen time used" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+pct+'"><i style="width:'+pct+'%"></i></span>';
  if(x.by&&x.by!==viewer)out+='<p class="muted">Added by '+esc(x.by==='parent'?P():C())+'</p>';
  if(viewer==='child'&&d===T)out+='<p class="hint">'+ic('star','fill')+(over>0?'Tomorrow is a fresh start.':'Each day within your limit earns 10 points.')+'</p>';
  return out+'</section>';
}
function screenWeek(viewer){
  var T=todayStr(),days=rangeDays(addDays(T,-6)),prev=rangeDays(addDays(T,-13));
  var ent=days.filter(function(d){return !!scrDay(d);}),avg=ent.length?Math.round(sum(ent,scrTotal)/ent.length):0;
  var past=days.filter(function(d){return d<T&&scrDay(d);}),ok=past.filter(scrOk).length;
  var pent=prev.filter(function(d){return !!scrDay(d);}),pavg=pent.length?Math.round(sum(pent,scrTotal)/pent.length):0;
  var out='<section class="card cat-screen"><div class="card-h"><h2>'+(viewer==='child'?'My screen time':'Screen time')+'</h2></div>'+
    '<div class="minis"><div class="mini"><b>'+(ent.length?fmtMin(avg):'–')+'</b><span>a day on average</span></div><div class="mini"><b>'+(past.length?ok+' of '+past.length:'–')+'</b><span>days within limit</span></div><div class="mini"><b>'+ent.length+' of 7</b><span>days added</span></div></div>'+
    scrWeekChart(days);
  if(ent.length&&pent.length)out+='<p class="muted">'+(avg<=pavg?fmtMin(pavg-avg)+' less':fmtMin(avg-pavg)+' more')+' a day than the 7 days before.</p>';
  if(viewer==='child')out+='<p class="hint">'+ic('flame','lockc')+'Within-limit streak: '+streak(scrOk)+' days. Best: '+bestStreak(scrOk)+'.</p>';
  else out+='<p class="hint">'+ic('tablet','lockc')+'<span>'+screenHow('parent')+' You can add or fix any day.</span></p>';
  return out+'</section>';
}

/* ---------- notifications ---------- */
var pushState='unknown';
function isIOS(){return /iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);}
function standalone(){return (window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;}
function b64uToBytes(s){var pad='='.repeat((4-s.length%4)%4),b=atob((s+pad).replace(/-/g,'+').replace(/_/g,'/')),o=new Uint8Array(b.length);for(var i=0;i<b.length;i++)o[i]=b.charCodeAt(i);return o;}
function swReady(){return Promise.race([navigator.serviceWorker.ready,new Promise(function(_,rej){setTimeout(function(){rej(new Error('Service worker not ready'));},8000);})]);}
async function checkPush(){
  var before=pushState;
  if(!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window)){pushState=isIOS()&&!standalone()?'needs-install':'unsupported';}
  else if(Notification.permission==='denied'){pushState='denied';}
  else{
    try{var reg=await swReady();var sub=await reg.pushManager.getSubscription();pushState=sub?'on':'off';if(sub&&API)API.savePush(sub.toJSON()).catch(function(){});}
    catch(e){pushState='off';}
  }
  if(pushState!==before)softRender();
}
function enablePush(){
  var asked;
  try{asked=Notification.requestPermission();}catch(e){asked=Promise.resolve(Notification.permission);}
  Promise.resolve(asked).then(async function(perm){
    if(perm!=='granted'){pushState=perm==='denied'?'denied':'off';render();return;}
    try{
      var reg=await swReady();
      var sub=await reg.pushManager.getSubscription();
      if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64uToBytes(API.vapidPublic)});
      await API.savePush(sub.toJSON());
      pushState='on';toast('Notifications are on');render();
    }catch(e){toast('Couldn’t turn on notifications. '+friendly(e));}
  });
}
async function disablePush(){
  try{if('serviceWorker' in navigator){var reg=await swReady();var sub=await reg.pushManager.getSubscription();if(sub){await API.removePush(sub.endpoint).catch(function(){});await sub.unsubscribe();}}}catch(e){}
}
function pushCard(viewer,onlyIfOff){
  if(onlyIfOff&&(pushState==='on'||pushState==='unknown'||pushState==='unsupported'||dismissed('push')))return '';
  var what=viewer==='child'?'test reminders and messages from '+esc(P()):'messages, reward requests and alerts from '+esc(C());
  var body;
  if(pushState==='needs-install')body='<p>To get '+what+' as notifications, add this app to your Home Screen first. In Safari, tap <b>Share</b>, then <b>Add to Home Screen</b>, and open the app from there.</p>';
  else if(pushState==='denied')body='<p>Notifications are blocked for this app. Turn them on in <b>Settings → Notifications → Growth</b>.</p>';
  else if(pushState==='on')body='<p class="allclear">'+ic('check')+'Notifications are on for this device.</p><button class="btn ghost wide" data-act="pushTest">Send a test notification</button>';
  else if(pushState==='unsupported')body='<p>This browser can’t show notifications. Use the app from the Home Screen on iPhone or iPad, or Chrome or Safari on a laptop.</p>';
  else body='<p>Get '+what+' on this device.</p><button class="btn primary wide" data-act="pushOn">'+ic('bell')+'Turn on notifications</button>';
  return '<section class="card push-card"><div class="card-h"><h2>Notifications</h2>'+(onlyIfOff?'<button class="icon-b" data-act="dismiss" data-k="push" aria-label="Hide this card">'+ic('x')+'</button>':'')+'</div>'+body+'</section>';
}

/* ---------- sign in and setup ---------- */
function logoSVG(){return '<svg viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="13" style="fill:var(--royal)"/><path d="M24 37V22" style="fill:none;stroke:var(--royal-ink)" stroke-width="3.2" stroke-linecap="round"/><path d="M24 25c0-6.5-4.6-10.5-11-10.5 0 6.6 4.6 10.5 11 10.5zM24 22c0-6 4.2-9.6 10.2-9.6 0 6-4.2 9.6-10.2 9.6z" style="fill:var(--royal-ink)"/></svg>';}
function authShell(inner){return '<main class="auth"><div class="auth-in"><div class="auth-brand"><span class="logo">'+logoSVG()+'</span><b>Growth Companion</b></div>'+inner+'</div></main>';}
function backBtn(){return '<button class="linkish back" data-act="authBack">'+ic('chev','flip')+'Back</button>';}
function vLoading(){return authShell('<p class="muted">Loading…</p>');}
function vNoConfig(){return authShell('<h1>Almost ready</h1><p>This app isn’t connected to its database yet. It will work as soon as setup finishes.</p>');}
function vAuth(){
  var a=ui.auth;
  if(!a.role)return authShell('<h1>Who’s using this device?</h1><div class="choose">'+
    '<button class="choice cat-study" data-act="authRole" data-v="child"><span class="choice-ic">'+ic('school')+'</span><span class="choice-txt"><b>I’m the child</b><small>Sign in with the family code</small></span>'+ic('chev','chev')+'</button>'+
    '<button class="choice cat-family" data-act="authRole" data-v="parent"><span class="choice-ic">'+ic('family')+'</span><span class="choice-txt"><b>I’m the parent</b><small>Sign in with your email</small></span>'+ic('chev','chev')+'</button></div>');
  if(a.role==='child')return authShell(backBtn()+'<h1>Hi! Let’s sign in</h1><form class="form" data-form="childlogin"><div class="field"><label class="lab" for="cl-code">Family code</label><input id="cl-code" name="code" maxlength="6" autocapitalize="characters" autocomplete="off" autocorrect="off" spellcheck="false" class="code-in" placeholder="ABC234"></div><div class="field"><label class="lab" for="cl-pw">Password</label><input id="cl-pw" name="pw" type="password" autocomplete="current-password"></div><button class="btn primary wide" type="submit">Sign in</button></form><p class="hint">'+ic('lock','lockc')+'<span>Forgot your password? Ask your parent to set a new one in their app.</span></p>');
  if(a.mode==='forgot')return authShell(backBtn()+'<h1>Reset your password</h1><form class="form" data-form="forgot"><div class="field"><label class="lab" for="fp-email">Email</label><input id="fp-email" name="email" type="email" autocomplete="email"></div><button class="btn primary wide" type="submit">Send reset link</button></form>');
  var up=a.mode==='signup';
  return authShell(backBtn()+'<h1>'+(up?'Create your account':'Welcome back')+'</h1>'+
    '<div class="seg inline" role="group" aria-label="Account"><button class="'+(!up?'on':'')+'" data-act="authMode" data-m="signin" aria-pressed="'+(!up)+'">Sign in</button><button class="'+(up?'on':'')+'" data-act="authMode" data-m="signup" aria-pressed="'+up+'">Create account</button></div>'+
    '<form class="form" data-form="'+(up?'signup':'login')+'"><div class="field"><label class="lab" for="pl-email">Email</label><input id="pl-email" name="email" type="email" autocomplete="email"></div><div class="field"><label class="lab" for="pl-pw">Password</label><input id="pl-pw" name="pw" type="password" autocomplete="'+(up?'new-password':'current-password')+'"></div><button class="btn primary wide" type="submit">'+(up?'Create account':'Sign in')+'</button></form>'+
    (up?'<p class="hint">'+ic('lock','lockc')+'<span>Use at least 6 characters. Only the first parent can create the family.</span></p>':'<button class="linkish" data-act="authMode" data-m="forgot">Forgot your password?</button>'));
}
function vRecovery(){return authShell('<h1>Choose a new password</h1><form class="form" data-form="newpass"><div class="field"><label class="lab" for="np-pw">New password</label><input id="np-pw" name="pw" type="password" autocomplete="new-password"></div><button class="btn primary wide" type="submit">Save password</button></form>');}
function appUrl(){return location.origin+location.pathname.replace(/index\.html$/,'');}
function iPadSteps(){
  return '<ol class="steps"><li>On '+esc(C())+'’s iPad, open Safari and go to <b class="url">'+esc(appUrl())+'</b></li><li>Tap <b>Share</b>, then <b>Add to Home Screen</b>. Open the app from the Home Screen.</li><li>Tap <b>I’m the child</b>, then enter the family code and his password.</li><li>Tap <b>Turn on notifications</b> so test reminders arrive.</li></ol>';
}
function codeBox(){return '<div class="codebox"><span class="eyebrow">Family code</span><b>'+esc(me&&me.code||'')+'</b></div>';}
function vSetup(){
  var st=ui.setupStep||1;
  if(st===1)return authShell('<p class="eyebrow">Step 1 of 2</p><h1>Set up your family</h1><form class="form" data-form="setup"><div class="row2"><div class="field"><label class="lab" for="su-c">Child’s name</label><input id="su-c" name="child" maxlength="20" value="Veer"></div><div class="field"><label class="lab" for="su-p">What your child calls you</label><input id="su-p" name="parent" maxlength="20" value="Mumma"></div></div><button class="btn primary wide" type="submit">Continue</button></form><p class="hint">'+ic('school','lockc')+'<span>His Grade 6A timetable and daily routine are already filled in. You can change them later.</span></p>');
  if(st===2)return authShell('<p class="eyebrow">Step 2 of 2</p><h1>'+esc(C())+'’s login</h1><p>Choose a password '+esc(C())+' will type on his iPad. Write it down for him.</p><form class="form" data-form="childpw"><div class="field"><label class="lab" for="cp-pw">Password for '+esc(C())+'</label><input id="cp-pw" name="pw" type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"></div><button class="btn primary wide" type="submit">Create '+esc(C())+'’s login</button></form><button class="linkish" data-act="setupSkip">Do this later</button>');
  return authShell('<h1>All set</h1>'+(me&&me.hasChild?codeBox()+iPadSteps():'<p>You can create '+esc(C())+'’s login later from the Family tab.</p>')+'<button class="btn primary wide" data-act="setupDone">Open the app</button>');
}
function childLoginCard(){
  return '<section class="card"><h2>'+esc(C())+'’s login</h2><p class="muted">'+(me.hasChild?esc(C())+' signs in with the family code and his password.':esc(C())+' doesn’t have a login yet.')+'</p>'+codeBox()+
    '<form class="form" data-form="childpw"><div class="field"><label class="lab" for="cp-pw">'+(me.hasChild?'New password for ':'Password for ')+esc(C())+'</label><input id="cp-pw" name="pw" type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"></div><button class="btn ghost wide" type="submit">'+(me.hasChild?'Set new password':'Create '+esc(C())+'’s login')+'</button></form>'+
    '<details class="how"><summary>How to set up '+esc(C())+'’s iPad</summary>'+iPadSteps()+'</details></section>';
}
function accountCard(){
  return '<section class="card"><h2>Your account</h2><p class="muted">'+esc(me.email||'')+'</p><button class="btn ghost wide" data-act="confirm" data-run="signout" data-text="Sign out of Growth Companion on this device?">Sign out</button></section>';
}
function authMsg(e,child){
  var m=(e&&e.message)||String(e||'');
  if(/invalid login|invalid credentials/i.test(m))return child?'That family code and password don’t match.':'That email and password don’t match.';
  if(/already registered|already exists/i.test(m))return 'There’s already an account with this email. Sign in instead.';
  if(/password should be|at least 6/i.test(m))return 'Use at least 6 characters for the password.';
  if(/rate limit|too many/i.test(m))return 'Too many tries. Wait a minute and try again.';
  return friendly(e);
}
function busy(f,p){
  var b=f&&f.querySelector('[type=submit]');if(b){b.disabled=true;}
  return Promise.resolve(p).finally(function(){if(b)b.disabled=false;});
}
async function enterApp(){
  ui.screen='loading';render();
  try{
    var s=await API.session();
    if(!s){ui.screen='auth';render();return;}
    me=await API.me();
    if(!me){ui.screen='auth';render();return;}
    if(!me.familyId){ui.screen='setup';ui.setupStep=1;render();return;}
    ui.mode=me.role;
    await refresh();
    API.subscribe(me.familyId,applyRemote);
    ui.screen='app';render();checkPush();
  }catch(e){
    ui.screen='auth';render();toast(friendly(e));
  }
}
async function createFamilyFlow(child,parent){
  await API.createFamily();
  me=await API.me();ui.mode='parent';
  await refresh();
  if(!server['family|names']){
    state=blankState();state.family={child:child,parent:parent};state.rewards=defaultRewards();
    save();
  }
  API.subscribe(me.familyId,applyRemote);
  ui.setupStep=me.hasChild?3:2;render();
}
async function signOutNow(){
  await disablePush();
  try{await API.signOut();}catch(e){}
  me=null;state=null;server={};ui.sheet=null;renderSheet();
  ui.auth={role:null,mode:'signin'};ui.screen='auth';render();
}

/* ---------- shared pieces ---------- */
function clocks(parentFirst){
  var c='<b data-clock="c">'+clockIn(TZ_C)+'</b>',p='<b data-clock="p">'+clockIn(TZ_P)+'</b>';
  if(parentFirst)return '<div class="clocks"><span>'+ic('clock')+'Dubai '+p+'</span><span>'+esc(C())+' in India '+c+'</span></div>';
  return '<div class="clocks"><span>'+ic('clock')+'India '+c+'</span><span>'+esc(P())+' in Dubai '+p+'</span></div>';
}
function goalBars(days,prev){
  var t=totals(days),p=prev?totals(prev):null,g=state.goals;
  return [['study','Study','study','pencil',g.study],['reading','Reading','read','book',g.reading],['activity','Sports & screen-free','active','ball',g.active]].map(function(r){
    var v=t[r[0]],pct=Math.min(100,Math.round(v/r[4]*100));
    var foot='';
    if(p){var dl=v-p[r[0]];foot+='<span>'+(dl>=0?'+':'−')+fmtMin(Math.abs(dl))+' vs the 7 days before</span>';}
    if(v>=r[4])foot+='<span class="pill good">'+ic('check')+' Goal reached</span>';
    return '<div class="goal cat-'+r[2]+'"><div class="goal-top"><span class="goal-l">'+ic(r[3])+esc(r[1])+'</span><span class="goal-v"><b>'+fmtMin(v)+'</b> of '+fmtMin(r[4])+'</span></div><span class="bar" role="progressbar" aria-label="'+esc(r[1])+'" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+pct+'"><i style="width:'+pct+'%"></i></span>'+(foot?'<div class="goal-foot">'+foot+'</div>':'')+'</div>';
  }).join('');
}
function logLine(l,tz,withDate){
  var o={i:'pencil',c:'study',t:'',m:'',note:'',tags:''};
  if(l.type==='study'){o.t=l.subject+' · '+fmtMin(l.min);o.m=l.topic||'';if(l.hw)o.tags='<span class="pill good">'+ic('check')+' Homework done</span>';}
  else if(l.type==='reading'){var b=bookById(l.bookId);o.i='book';o.c='read';o.t=(b?b.title:'Reading')+' · '+l.pages+' pages';o.m=fmtMin(l.min);o.note=l.note||'';}
  else {var k=KINDS[l.kind]||KINDS.outdoor;o.i=k.i;o.c=l.kind==='creative'?'create':'active';o.t=l.what+' · '+fmtMin(l.min);o.m=k.l;}
  var when=(withDate?relDay(l.date)+', ':'')+tsTime(l.ts,tz);
  return {html:'<span class="h-ic cat-'+o.c+'">'+ic(o.i)+'</span><span class="h-main"><span class="h-t">'+esc(o.t)+'</span><span class="h-m">'+esc(o.m?o.m+' · '+when:when)+'</span>'+(o.note?'<span class="h-note">“'+esc(o.note)+'”</span>':'')+(o.tags?'<span class="h-tags">'+o.tags+'</span>':'')+'</span>'};
}
function thread(viewer){
  var tz=viewer==='child'?TZ_C:TZ_P;
  var ms=state.messages.slice().sort(function(a,b){return a.ts-b.ts;}).slice(-24);
  var out='',last='';
  ms.forEach(function(m){
    var dk=dateOf(m.ts,tz);
    if(dk!==last){out+='<li class="sep">'+relDay(dk)+'</li>';last=dk;}
    var mine=m.from===viewer,who=m.from==='parent'?P():C();
    var st=m.stamp&&STAMPS[m.stamp]?'<span class="stampmini">'+STAMPS[m.stamp]+'</span>':'';
    if(m.kind==='remark')out+='<li class="msg remark"><div class="diary"><p class="lbl">Diary remark · '+fmtShort(m.date)+'</p><p class="hand">'+st+esc(m.text)+'</p><p class="sig">— '+esc(P())+', '+tsTime(m.ts,tz)+'</p></div></li>';
    else out+='<li class="msg '+(mine?'mine':'theirs')+'"><div class="bubble">'+st+esc(m.text)+'</div><span class="mt">'+esc(who)+' · '+tsTime(m.ts,tz)+'</span></li>';
  });
  return '<ul class="thread">'+(out||'<li class="empty">No messages yet.</li>')+'</ul>';
}

/* ---------- child views ---------- */
function vChildToday(){
  var T=todayStr(),y=addDays(T,-1);
  var tasks=state.tasks.filter(function(t){return t.date===T;});
  var left=state.tasks.filter(function(t){return t.date===y&&!t.done;});
  var mood=state.moods[T];
  var rs=streak(function(d){return has(d,'reading');}),cs=streak(checkedIn);
  var out='<section class="hello"><p class="eyebrow">'+fmtLong(T)+'</p><h1>Hi '+esc(C())+'</h1>'+clocks(false)+'</section>';
  out+='<div class="strip"><button class="stat pts" data-act="tab" data-tab="rewards">'+ic('star','fill')+'<b>'+balance()+'</b><span>points</span></button><div class="stat str">'+ic('flame','fill')+'<b>'+rs+'</b><span>day reading streak</span></div><div class="stat chk">'+ic('check')+'<b>'+cs+'</b><span>day check-in streak</span></div></div>';
  out+=pushCard('child',true);
  var due=state.exams.filter(function(e){var n=diffDays(T,e.date),r=e.remind||[3,1];return n>=0&&r.length&&n<=Math.max.apply(null,r);}).sort(function(a,b){return a.date.localeCompare(b.date);});
  if(due.length){
    out+='<section class="card"><div class="card-h"><h2>Test reminders</h2><span class="pill new">'+ic('bell')+due.length+'</span></div><ul class="updates">'+due.map(function(e){
      var n=diffDays(T,e.date),when=n===0?'is today':n===1?'is tomorrow':'in '+n+' days';
      var tip=n===0?'You’ve prepared. Do your best!':n===1?'A quick revision tonight, then sleep on time.':'Plan some revision time before then.';
      return '<li class="upd cat-family"><span class="upd-ic">'+ic('school')+'</span><div class="upd-main"><p class="upd-t">'+esc(e.subject+' '+e.kind.toLowerCase()+' '+when)+'</p><p class="upd-s">'+(e.portion?'Portion: '+esc(e.portion)+'. ':'')+tip+'</p>'+(n>0?'<div class="upd-a"><button class="btn ghost" data-act="sheet" data-s="block" data-d="'+T+'" data-title="'+esc(e.subject)+' revision" data-cat="study">'+ic('plus')+'Add revision to today</button></div>':'')+'</div></li>';
    }).join('')+'</ul></section>';
  }
  if(mood){
    out+='<section class="card mood-done">'+face(mood.face,52)+'<div class="md-main"><p class="eyebrow">Today’s check-in</p><p class="md-l">You’re feeling <b>'+MOODS[mood.face].toLowerCase()+'</b></p>'+(mood.note?'<p class="md-note">'+(mood.share?'Shared with '+esc(P()):'Private note')+' · “'+esc(mood.note)+'”</p>':'')+'</div><button class="tiny" data-act="sheet" data-s="mood">Change</button></section>';
  } else {
    out+='<section class="card"><div class="card-h"><h2>How are you feeling?</h2><span class="muted">+2</span></div><div class="faces-row">'+Object.keys(MOODS).map(function(k){return '<button class="facebtn" data-act="sheet" data-s="mood" data-face="'+k+'">'+face(k,44)+'<span>'+MOODS[k]+'</span></button>';}).join('')+'</div></section>';
  }
  var pm=state.messages.filter(function(m){return m.from==='parent';}).sort(function(a,b){return b.ts-a.ts;})[0];
  var un=unread('parent');
  if(pm){
    var st=pm.stamp&&STAMPS[pm.stamp]?'<span class="stampmini">'+STAMPS[pm.stamp]+'</span>':'';
    out+='<section class="card"><div class="card-h"><h2>From '+esc(P())+'</h2>'+(un?'<span class="pill new">'+un+' new</span>':'')+'</div><div class="diary"><p class="hand">'+st+esc(pm.text)+'</p><p class="sig">— '+esc(P())+', '+relDay(dateOf(pm.ts,TZ_C))+' '+tsTime(pm.ts,TZ_C)+'</p></div><button class="btn ghost wide" data-act="sheet" data-s="messages">'+ic('chat')+'Messages</button></section>';
  } else {
    out+='<section class="card"><div class="card-h"><h2>Messages</h2></div><p class="empty">No messages yet. Say hi to '+esc(P())+'.</p><button class="btn ghost wide" data-act="sheet" data-s="messages">'+ic('chat')+'Write to '+esc(P())+'</button></section>';
  }
  var nn=nowNext(T),m=nowMin();
  var nowT,nowS,nextT,nextS;
  if(nn.cur){nowT=tt(nn.cur.title);nowS=nn.cur.end?'until '+fmtTime(nn.cur.end):'Sleep well';var cpp=curPeriod(T);if(nn.cur.cat==='school'&&cpp){nowT=cpp.i===-1?'Break':cpp.subj;nowS=(cpp.i===-1?'':'Period '+ROMAN[cpp.i]+' · ')+'until '+fmtTime(cpp.end);}}
  else if(nn.first&&m<toMin(nn.first.start)){nowT='Sleeping time';nowS='Day starts '+fmtTime(nn.first.start);}
  else {nowT='Free time';nowS='Nothing planned';}
  if(nn.next){nextT=tt(nn.next.title);nextS='at '+fmtTime(nn.next.start);}else{nextT='Tomorrow';nextS='Plan it tonight';}
  out+='<section class="card"><div class="card-h"><h2>My plan</h2><button class="tiny" data-act="tab" data-tab="plan">Full day</button></div><div class="nn-grid"><div class="nn now"><span class="eyebrow">Now</span><b>'+esc(nowT)+'</b><small>'+esc(nowS)+'</small></div><div class="nn"><span class="eyebrow">Next</span><b>'+esc(nextT)+'</b><small>'+esc(nextS)+'</small></div></div>'+(isHoliday(T)?'<p class="tmr">'+ic('school')+'<span><b>Today is a holiday.</b> Using the day-off plan.</span></p>':'')+tomorrowLine(T)+(isSchoolDay(wd(T))?'<button class="linkish" data-act="holiday" data-d="'+T+'">'+(isHoliday(T)?'It’s a school day after all':'No school today? Mark it as a holiday')+'</button>':'')+'</section>';
  var done=tasks.filter(function(t){return t.done;}).length;
  out+='<section class="card"><div class="card-h"><h2>Today’s tasks</h2><span class="muted">'+done+' of '+tasks.length+' done</span></div>';
  if(left.length)out+='<div class="leftover"><span>'+left.length+' unfinished from yesterday</span><button class="tiny" data-act="moveLeft">Move to today</button></div>';
  out+='<ul class="tasks">'+(tasks.length?tasks.map(taskRow).join(''):'<li class="empty">No tasks yet. Add homework, chores or anything you want to remember.</li>')+'</ul><button class="btn ghost wide" data-act="sheet" data-s="task-add">'+ic('plus')+'Add a task</button>'+schoolLink('linkish','Open school homework')+'</section>';
  var g=state.goals;
  out+='<section class="card"><div class="card-h"><h2>Today so far</h2><span class="muted">Tap to log</span></div><div class="logrows">'+
    [['study','Study','pencil','study','log-study',aim(g.study)],['reading','Reading','book','read','log-reading',aim(g.reading)],['activity','Sports & screen-free','ball','active','log-activity',aim(g.active)]].map(function(r){
      var v=minOn(T,r[0]),pct=Math.min(100,Math.round(v/r[5]*100));
      return '<button class="logrow cat-'+r[3]+'" data-act="sheet" data-s="'+r[4]+'"><span class="lr-ic">'+ic(r[2])+'</span><span class="lr-main"><span class="lr-top"><b>'+r[1]+'</b><span>'+fmtMin(v)+' <small>/ '+fmtMin(r[5])+'</small></span></span><span class="bar"><i style="width:'+pct+'%"></i></span></span><span class="lr-add">'+ic('plus')+'</span></button>';
    }).join('')+'</div><button class="btn primary wide" data-act="sheet" data-s="speak">'+ic('mic')+'Say what you did</button></section>';
  out+=screenCard(T,'child');
  out+='<button class="linkish" data-act="sheet" data-s="see">'+ic('eye')+'What '+esc(P())+' can see</button>';
  return out;
}
function tomorrowLine(T){
  var t=addDays(T,1),w=wd(t);
  if(!isSchoolDay(w))return '<p class="tmr">'+ic('school')+'<span>Tomorrow is '+DOWL[w]+'. No school.</span></p>';
  if(isHoliday(t))return '<p class="tmr">'+ic('school')+'<span>Tomorrow is a holiday. No school.</span></p>';
  var seen=[];(state.timetable[w]||[]).forEach(function(p){if(p&&seen.indexOf(p)<0)seen.push(p);});
  return '<p class="tmr">'+ic('school')+'<span><b>Pack for '+DOWL[w]+':</b> '+esc(seen.join(', '))+'</span></p>';
}
function taskRow(t){
  var meta=TASKCAT[t.cat]||'Task';
  if(t.from==='parent')meta+=' · <span class="from">from '+esc(P())+'</span>';
  return '<li class="'+(t.done?'done':'')+'"><button class="tick '+(t.done?'on':'')+'" data-act="toggleTask" data-id="'+t.id+'" aria-pressed="'+t.done+'" aria-label="'+(t.done?'Mark not done: ':'Mark done: ')+esc(t.title)+'">'+ic('check')+'</button><span class="t-body"><span class="t-title">'+esc(t.title)+'</span><span class="t-meta">'+meta+'</span></span><button class="icon-b" data-act="confirm" data-run="delTask" data-id="'+t.id+'" data-text="Remove this task?" aria-label="Remove task">'+ic('x')+'</button></li>';
}
function vChildPlan(){
  var T=todayStr();
  var d=(ui.planDay&&diffDays(T,ui.planDay)>=0&&diffDays(T,ui.planDay)<7)?ui.planDay:T;
  var plan=sortPlan(getPlan(d)),m=nowMin(),w=wd(d),school=isSchoolDate(d),hol=isHoliday(d);
  var out='<section class="hello"><p class="eyebrow">Plan my day</p><h1>'+(d===T?'Today':d===addDays(T,1)?'Tomorrow':DOWL[w])+'</h1></section>';
  out+='<div class="daychips" role="group" aria-label="Choose a day">'+rangeDays(T).map(function(x,i){return '<button class="daychip '+(x===d?'on':'')+'" data-act="planDay" data-d="'+x+'" aria-pressed="'+(x===d)+'"><span>'+(i===0?'Today':DOW[wd(x)])+'</span><b>'+(+x.slice(8))+'</b></button>';}).join('')+'</div>';
  out+='<section class="card"><div class="card-h"><h2>'+(school?'School day':hol?'Holiday':'Day off')+'</h2>'+(state.plans[d]?'<span class="pill">Changed for this day</span>':'<span class="muted">Usual routine</span>')+'</div><ul class="tl">'+plan.map(function(b){
    var c=CAT[b.cat]||CAT.routine,now=d===T&&inBlock(b,m);
    return '<li class="cat-'+c.c+(now?' now':'')+'"><button class="tl-row" data-act="sheet" data-s="block" data-d="'+d+'" data-id="'+b.id+'"><span class="tl-time">'+fmtTime(b.start)+'</span><span class="tl-dot"></span><span class="tl-body"><span class="tl-title">'+esc(tt(b.title))+(now?'<em class="pill now-pill">Now</em>':'')+'</span><span class="tl-meta">'+c.l+(b.end?' · until '+fmtTime(b.end):'')+'</span></span></button></li>';
  }).join('')+'</ul><div class="btnrow"><button class="btn primary" data-act="sheet" data-s="block" data-d="'+d+'">'+ic('plus')+'Add to plan</button>'+(state.plans[d]?'<button class="btn ghost" data-act="saveRoutine" data-d="'+d+'">Make it my usual</button>':'')+'</div>'+(state.plans[d]?'<button class="linkish" data-act="resetPlan" data-d="'+d+'">Go back to the usual routine</button>':'')+(isSchoolDay(w)?'<button class="linkish" data-act="holiday" data-d="'+d+'">'+ic('school')+(hol?'It’s a school day after all':'No school '+(d===T?'today':'this day')+'? Mark it as a holiday')+'</button>':'')+'</section>';
  if(school){
    var per=state.timetable[w]||[],cp=curPeriod(d),rows='';
    PERIODS.forEach(function(t,i){
      if(i===4)rows+='<li class="brk'+(cp&&cp.i===-1?' now':'')+'"><span class="pn">–</span><span class="p-t">'+fmtTime('11:10')+'</span><span>Break</span></li>';
      rows+='<li class="'+(cp&&cp.i===i?'now':'')+'"><span class="pn">'+ROMAN[i]+'</span><span class="p-t">'+fmtTime(t[0])+'</span><span>'+esc(per[i]||'')+'</span></li>';
    });
    out+='<section class="card"><div class="card-h"><h2>Timetable · '+DOWL[w]+'</h2><button class="tiny" data-act="sheet" data-s="tt" data-w="'+w+'">Edit</button></div><p class="tt-sub">Grade '+SCHOOL.grade+' · classes '+fmtTime(PERIODS[0][0])+' to '+fmtTime(PERIODS[6][1])+'</p><ol class="periods">'+rows+'</ol>'+schoolLink('btn ghost wide','Open school homework')+'</section>';
  }
  var ex=state.exams.filter(function(e){return e.date>=T;}).sort(function(a,b){return a.date.localeCompare(b.date);});
  out+='<section class="card"><div class="card-h"><h2>Upcoming tests</h2><button class="tiny" data-act="sheet" data-s="exam">Add</button></div>'+(ex.length?'<ul class="exams">'+ex.map(function(e){var n=diffDays(T,e.date);return '<li><button class="ex-row" data-act="sheet" data-s="exam" data-id="'+e.id+'"><span class="ex-count">'+(n===0?'<b>!</b><small>Today</small>':'<b>'+n+'</b><small>'+(n===1?'day':'days')+'</small>')+'</span><span class="ex-body"><span class="ex-title">'+esc(e.subject)+' · '+esc(e.kind)+'</span><span class="ex-meta">'+fmtShort(e.date)+(e.portion?' · Portion: '+esc(e.portion):'')+'</span><span class="ex-meta">'+remindText(e.remind||[3,1])+'</span></span></button></li>';}).join('')+'</ul>':'<p class="empty">No tests coming up. Add one when your teacher announces it.</p>')+'</section>';
  return out;
}
function vChildProgress(){
  var T=todayStr(),days=rangeDays(addDays(T,-6));
  var out='<section class="hello"><p class="eyebrow">'+fmtShort(days[0])+' – '+fmtShort(T)+'</p><h1>My progress</h1></section>';
  out+='<section class="card"><div class="card-h"><h2>Last 7 days</h2></div><div class="goals">'+goalBars(days)+'</div><p class="hint">'+ic('target','lockc')+'Weekly goals you and '+esc(P())+' agreed on.</p></section>';
  out+=screenWeek('child');
  out+='<section class="card"><h2>Minutes each day</h2>'+chart(days)+'</section>';
  var sk=[['Reading','read','book',function(d){return has(d,'reading');}],['Study','study','pencil',function(d){return has(d,'study');}],['Active','active','ball',function(d){return has(d,'activity');}],['Check-in','good','heart',checkedIn]];
  out+='<section class="card"><h2>Streaks</h2><div class="streaks">'+sk.map(function(s){var n=streak(s[3]),b=bestStreak(s[3]);return '<div class="streak cat-'+s[1]+'"><div class="streak-top">'+ic(s[2])+'<b>'+n+'</b></div><span>'+(n===1?'day':'days')+' of '+s[0].toLowerCase()+'</span><small>Best: '+b+' days</small></div>';}).join('')+'</div></section>';
  out+='<section class="card"><div class="card-h"><h2>My books</h2><button class="tiny" data-act="sheet" data-s="log-reading">Log reading</button></div><ul class="books">'+(state.books.length?'':'<li class="empty">No books yet. Log your reading and add the book you’re reading.</li>')+state.books.slice().reverse().map(function(b,i){var pct=Math.min(100,Math.round(b.read/b.total*100));var cc=['read','study','create','active'][i%4];return '<li class="book cat-'+cc+'"><span class="spine"></span><span class="bk-main"><span class="bk-t">'+esc(b.title)+'</span><span class="bk-a">'+esc(b.author||'')+(b.author?' · ':'')+(b.read>=b.total?'Finished '+(b.finishedOn?fmtShort(b.finishedOn):''):'Page '+b.read+' of '+b.total)+'</span><span class="bar"><i style="width:'+pct+'%"></i></span></span></li>';}).join('')+'</ul></section>';
  var st=stampList();
  out+='<section class="card"><div class="card-h"><h2>Stamps</h2><span class="muted">'+st.filter(function(s){return s.got;}).length+' of '+st.length+'</span></div><div class="stamps">'+st.map(function(s){return '<div class="stamp '+(s.got?'got':'locked')+'">'+stampSVG(s)+'<b>'+esc(s.name)+'</b><small>'+(s.got?esc(s.desc):esc(s.p))+'</small></div>';}).join('')+'</div></section>';
  var hist=state.logs.slice().sort(function(a,b){return b.ts-a.ts;}).slice(0,15);
  out+='<section class="card"><div class="card-h"><h2>History</h2><span class="muted">You can delete anything</span></div><ul class="hist">'+(hist.length?hist.map(function(l){return '<li>'+logLine(l,TZ_C,true).html+'<button class="icon-b" data-act="confirm" data-run="delLog" data-id="'+l.id+'" data-text="Delete this log? Its points go too." aria-label="Delete this log">'+ic('trash')+'</button></li>';}).join(''):'<li class="empty">Nothing logged yet.</li>')+'</ul></section>';
  out+=pushCard('child',false);
  out+='<button class="linkish" data-act="confirm" data-run="signout" data-text="Sign out on this iPad? You’ll need the family code and your password to sign back in.">Sign out</button>';
  return out;
}
function vChildRewards(){
  var bal=balance();
  var out='<section class="balance"><span class="eyebrow">My points</span><div class="bal">'+ic('star','fill')+'<b>'+bal+'</b></div><p>'+earned()+' earned · '+held()+' used or waiting</p></section>';
  out+='<section class="card"><h2>Family rewards</h2><ul class="rewards">'+state.rewards.map(function(r){
    var pend=state.redemptions.some(function(x){return x.rewardId===r.id&&x.status==='pending';});
    var act=pend?'<span class="pill wait">Waiting for '+esc(P())+'</span>':bal>=r.cost?'<button class="btn primary" data-act="ask" data-id="'+r.id+'">Ask</button>':'<span class="need">'+(r.cost-bal)+' more points</span>';
    return '<li class="rw"><span class="rw-cost">'+ic('star','fill')+r.cost+'</span><span class="rw-t">'+esc(r.title)+'</span>'+act+'</li>';
  }).join('')+'</ul><p class="hint">'+ic('family','lockc')+'Rewards are chosen together. Ask '+esc(P())+' on your call if you want a new one.</p></section>';
  var rq=state.redemptions.slice().sort(function(a,b){return b.ts-a.ts;});
  out+='<section class="card"><h2>My requests</h2>'+(rq.length?'<ul class="hist">'+rq.map(function(x){var p=x.status==='pending'?'<span class="pill wait">Waiting</span>':x.status==='approved'?'<span class="pill good">Yes!</span>':'<span class="pill">Not this time</span>';return '<li><span class="h-ic cat-star">'+ic('gift')+'</span><span class="h-main"><span class="h-t">'+esc(x.title)+'</span><span class="h-m">'+x.cost+' points · '+relDay(dateOf(x.ts,TZ_C))+'</span></span>'+p+'</li>';}).join('')+'</ul>':'<p class="empty">No requests yet.</p>')+'</section>';
  out+='<section class="card"><h2>How I earn points</h2><ul class="earn"><li>Finish a task<b>5</b></li><li>Log study time<b>10, or 15 for 45+ min</b></li><li>Log reading<b>10, +5 with a summary</b></li><li>Log sports or screen-free time<b>10</b></li><li>Stay within screen time for the day<b>10</b></li><li>Mood check-in<b>2</b></li></ul></section>';
  return out;
}

/* ---------- parent views ---------- */
function updates(){
  var T=todayStr(),u=[],n=state.notify;
  if(n.screen)[T,addDays(T,-1)].forEach(function(d){
    if(!scrDay(d))return;var tot=scrTotal(d),lim=scrLimit(d);if(tot<=lim)return;
    u.push({c:'family',i:'tablet',t:C()+' used the iPad for '+fmtMin(tot)+' '+relDay(d).toLowerCase(),s:fmtMin(tot-lim)+' over the '+fmtMin(lim)+' limit',a:'<button class="btn ghost" data-act="cheer" data-text="Let’s try to stay within screen time today. Cricket or a good book instead?">'+ic('heart')+'Send a gentle note</button>'});
  });
  if(n.reward)state.redemptions.filter(function(r){return r.status==='pending';}).forEach(function(r){u.push({c:'star',i:'gift',t:C()+' asked for “'+r.title+'”',s:r.cost+' points · '+relDay(dateOf(r.ts,TZ_C)),a:'<button class="btn good" data-act="redeem" data-id="'+r.id+'" data-st="approved">Say yes</button><button class="btn ghost" data-act="redeem" data-id="'+r.id+'" data-st="declined">Not this time</button>'});});
  if(n.mood)[T,addDays(T,-1)].forEach(function(d){var md=state.moods[d];if(md&&(md.face==='sad'||md.face==='frustrated'))u.push({c:'family',i:'heart',t:C()+' felt '+MOODS[md.face].toLowerCase()+' '+relDay(d).toLowerCase(),s:md.share&&md.note?'“'+md.note+'”':'Maybe ask about it on your call. Listening helps more than fixing.',a:'<button class="btn ghost" data-act="cheer" data-text="Sending you a big hug. Tell me about it tonight?">'+ic('heart')+'Send a hug</button>'});});
  if(n.exam)state.exams.filter(function(e){var k=diffDays(T,e.date);return k>=0&&k<=7;}).sort(function(a,b){return a.date.localeCompare(b.date);}).forEach(function(e){var k=diffDays(T,e.date);u.push({c:'family',i:'school',t:e.subject+' '+e.kind.toLowerCase()+' '+(k===0?'today':k===1?'tomorrow':'in '+k+' days'),s:fmtShort(e.date)+(e.portion?' · '+e.portion:''),a:'<button class="btn ghost" data-act="cheer" data-text="Good luck for your '+esc(e.subject)+' '+esc(e.kind.toLowerCase())+'! You have prepared well." data-stamp="keepgoing">Send good luck</button>'});});
  if(n.milestone){
    state.books.forEach(function(b){if(b.finishedOn&&diffDays(b.finishedOn,T)<=7)u.push({c:'read',i:'book',t:C()+' finished '+b.title,s:relDay(b.finishedOn)+' · '+b.total+' pages',a:'<button class="btn ghost" data-act="cheer" data-text="You finished a whole book! What was your favourite part?" data-stamp="shabash">Send a Shabash</button>'});});
    var rs=streak(function(d){return has(d,'reading');});if(rs>=5)u.push({c:'active',i:'flame',t:rs+'-day reading streak',s:C()+' has read every day since '+fmtShort(addDays(T,-(rs-1))),a:''});
  }
  if(n.weekly&&wd(T)===0)u.push({c:'study',i:'week',t:'Your weekly summary is ready',s:'Last 7 days of study, reading and activity',a:'<button class="btn ghost" data-act="tab" data-tab="week">Open week</button>'});
  return u;
}
function vParentOverview(){
  var T=todayStr(),d=ui.pday===-1?addDays(T,-1):T;
  var h=hourIn(TZ_P),greet=h<12?'Good morning':h<17?'Good afternoon':'Good evening';
  var nn=nowNext(T);
  var out='<section class="hello"><p class="eyebrow">'+fmtLong(dateOf(Date.now(),TZ_P))+'</p><h1>'+greet+', '+esc(P())+'</h1>'+clocks(true)+
    (isHoliday(T)?'<p class="planline">'+ic('school')+esc(C())+' marked today as a school holiday.</p>':'')+'<p class="planline">'+ic('plan')+'On '+esc(C())+'’s plan now: <b>'+esc(nn.cur?tt(nn.cur.title):'Free time')+'</b>'+(nn.cur&&nn.cur.end?' until '+fmtTime(nn.cur.end):'')+'</p></section>';
  out+=pushCard('parent',true);
  var u=updates();
  out+='<section class="card"><div class="card-h"><h2>Updates for you</h2>'+(u.length?'<span class="pill new">'+u.length+'</span>':'')+'</div>'+(u.length?'<ul class="updates">'+u.map(function(x){return '<li class="upd cat-'+x.c+'"><span class="upd-ic">'+ic(x.i)+'</span><div class="upd-main"><p class="upd-t">'+esc(x.t)+'</p><p class="upd-s">'+esc(x.s)+'</p>'+(x.a?'<div class="upd-a">'+x.a+'</div>':'')+'</div></li>';}).join('')+'</ul>':'<p class="allclear">'+ic('check')+'Nothing needs you right now.</p>')+'</section>';
  out+='<div class="seg inline" role="group" aria-label="Day"><button class="'+(ui.pday===0?'on':'')+'" data-act="pday" data-v="0" aria-pressed="'+(ui.pday===0)+'">Today</button><button class="'+(ui.pday===-1?'on':'')+'" data-act="pday" data-v="-1" aria-pressed="'+(ui.pday===-1)+'">Yesterday</button></div>';
  var tasks=state.tasks.filter(function(t){return t.date===d;}),done=tasks.filter(function(t){return t.done;}).length;
  var pages=sum(logsOn(d,'reading'),function(l){return l.pages;});
  out+=screenCard(d,'parent');
  out+='<div class="tiles"><div class="tile cat-good">'+ic('check')+'<b>'+done+'/'+tasks.length+'</b><span>tasks done</span></div><div class="tile cat-study">'+ic('pencil')+'<b>'+fmtMin(minOn(d,'study'))+'</b><span>study</span></div><div class="tile cat-read">'+ic('book')+'<b>'+fmtMin(minOn(d,'reading'))+'</b><span>reading'+(pages?' · '+pages+' pages':'')+'</span></div><div class="tile cat-active">'+ic('ball')+'<b>'+fmtMin(minOn(d,'activity'))+'</b><span>sports &amp; screen-free</span></div></div>';
  var md=state.moods[d];
  out+='<div class="moodline">'+(md?face(md.face,40):'<span class="h-ic cat-life">'+ic('heart')+'</span>')+'<div class="md-main"><span class="eyebrow">Mood check-in</span><span>'+(md?'Feeling <b>'+MOODS[md.face].toLowerCase()+'</b>'+(md.note&&md.share?' · “'+esc(md.note)+'”':''):'No check-in yet')+'</span></div></div>';
  var logs=logsOn(d).sort(function(a,b){return a.ts-b.ts;});
  out+='<section class="card"><div class="card-h"><h2>What '+esc(C())+' logged</h2><span class="muted">'+relDay(d)+'</span></div>'+(logs.length?'<ul class="hist">'+logs.map(function(l){return '<li>'+logLine(l,TZ_P,false).html+'</li>';}).join('')+'</ul>':'<p class="empty">'+(d===T?esc(C())+' hasn’t logged anything yet today. Most logging happens after school.':'Nothing was logged.')+'</p>')+
    (tasks.length?'<ul class="tasks">'+tasks.map(function(t){return '<li class="'+(t.done?'done':'')+'"><span class="tick ro '+(t.done?'on':'')+'" aria-label="'+(t.done?'Done':'Not done')+'">'+ic('check')+'</span><span class="t-body"><span class="t-title">'+esc(t.title)+'</span><span class="t-meta">'+(TASKCAT[t.cat]||'Task')+(t.from==='parent'?' · <span class="from">your suggestion</span>':'')+'</span></span></li>';}).join('')+'</ul>':'')+'</section>';
  var rm=state.messages.filter(function(m){return m.kind==='remark'&&m.date===d;})[0];
  out+='<section class="card"><div class="card-h"><h2>'+(rm?'You signed the diary':'Sign '+esc(C())+'’s diary')+'</h2><span class="muted">'+relDay(d)+'</span></div>';
  if(rm)out+='<div class="diary"><p class="hand">'+(rm.stamp&&STAMPS[rm.stamp]?'<span class="stampmini">'+STAMPS[rm.stamp]+'</span>':'')+esc(rm.text)+'</p><p class="sig">— '+esc(P())+', '+tsTime(rm.ts,TZ_P)+'</p></div>';
  else out+='<form class="form" data-form="remark" data-d="'+d+'"><div class="field"><label class="lab" for="rm-text">A short remark '+esc(C())+' will see</label><textarea id="rm-text" name="text" maxlength="240" placeholder="What made you smile about today?"></textarea></div><div class="chips">'+['Shabash! Great day.','Proud of how you managed your time.','Lovely reading today.','Tomorrow is a fresh start. Sleep well.'].map(function(c){return '<button type="button" class="chip" data-act="setval" data-t="rm-text" data-v="'+esc(c)+'">'+esc(c)+'</button>';}).join('')+'</div><button class="btn primary wide" type="submit">'+ic('pencil')+'Sign the diary</button></form>';
  out+='</section>';
  out+='<section class="card"><h2>Quick encouragement</h2><div class="chips">'+[['Proud of you!','proud'],['Great effort today','welldone'],['Keep going, you can do it','keepgoing'],['Missing you. Talk tonight?','']].map(function(c){return '<button class="chip" data-act="cheer" data-text="'+esc(c[0])+'" data-stamp="'+c[1]+'">'+esc(c[0])+'</button>';}).join('')+'</div><p class="hint">'+ic('bell','lockc')+'Sends straight to '+esc(C())+'’s messages.</p></section>';
  return out;
}
function vParentWeek(){
  var T=todayStr(),days=rangeDays(addDays(T,-6)),prev=rangeDays(addDays(T,-13));
  var out='<section class="hello"><p class="eyebrow">'+fmtShort(days[0])+' – '+fmtShort(T)+'</p><h1>The week</h1></section>';
  out+=screenWeek('parent');
  out+='<section class="card"><h2>Weekly goals</h2><div class="goals">'+goalBars(days,prev)+'</div></section>';
  out+='<section class="card"><h2>Minutes each day</h2>'+chart(days)+'</section>';
  var hl=[];
  var rd=days.filter(function(d){return has(d,'reading');}).length;hl.push(['book','Read on '+rd+' of 7 days']);
  var tk=state.tasks.filter(function(t){return days.indexOf(t.date)>-1;});hl.push(['check',tk.filter(function(t){return t.done;}).length+' of '+tk.length+' tasks finished, including '+tk.filter(function(t){return t.done&&t.cat==='homework';}).length+' homework']);
  var acts=state.logs.filter(function(l){return l.type==='activity'&&days.indexOf(l.date)>-1;});
  if(acts.length){var top=acts.reduce(function(a,b){return b.min>a.min?b:a;});hl.push(['ball','Longest activity: '+top.what+', '+fmtMin(top.min)]);}
  var ms=days.map(function(d){return state.moods[d];}).filter(Boolean);
  if(ms.length){var cnt={};ms.forEach(function(x){cnt[x.face]=(cnt[x.face]||0)+1;});var mf=Object.keys(cnt).sort(function(a,b){return cnt[b]-cnt[a];})[0];hl.push(['heart','Checked in '+ms.length+' times, mostly '+MOODS[mf].toLowerCase()]);}
  state.books.forEach(function(b){if(b.finishedOn&&days.indexOf(b.finishedOn)>-1)hl.push(['star','Finished '+b.title]);});
  out+='<section class="card"><h2>Highlights</h2><ul class="hl">'+hl.map(function(x){return '<li>'+ic(x[0])+'<span>'+esc(x[1])+'</span></li>';}).join('')+'</ul></section>';
  var bys={};state.logs.forEach(function(l){if(l.type==='study'&&days.indexOf(l.date)>-1)bys[l.subject]=(bys[l.subject]||0)+l.min;});
  var arr=Object.keys(bys).map(function(k){return [k,bys[k]];}).sort(function(a,b){return b[1]-a[1];});var mx=arr.length?arr[0][1]:1;
  out+='<section class="card"><h2>Study by subject</h2>'+(arr.length?'<ul class="subj">'+arr.map(function(x){return '<li><span>'+esc(x[0])+'</span><span class="sb-bar"><i style="width:'+Math.round(x[1]/mx*100)+'%"></i></span><span class="sb-v">'+fmtMin(x[1])+'</span></li>';}).join('')+'</ul>':'<p class="empty">No study logged this week.</p>')+'</section>';
  var cur=state.books.filter(function(b){return b.read<b.total;})[0];
  if(cur){var pct=Math.round(cur.read/cur.total*100);out+='<section class="card"><h2>Reading now</h2><div class="book cat-read"><span class="spine"></span><span class="bk-main"><span class="bk-t">'+esc(cur.title)+'</span><span class="bk-a">'+esc(cur.author||'')+' · page '+cur.read+' of '+cur.total+'</span><span class="bar"><i style="width:'+pct+'%"></i></span></span></div></section>';}
  var ex=state.exams.filter(function(e){return e.date>=T;}).sort(function(a,b){return a.date.localeCompare(b.date);}).slice(0,4);
  if(ex.length)out+='<section class="card"><h2>Tests coming up</h2><ul class="hist">'+ex.map(function(e){return '<li><span class="h-ic cat-family">'+ic('school')+'</span><span class="h-main"><span class="h-t">'+esc(e.subject)+' · '+esc(e.kind)+'</span><span class="h-m">'+fmtShort(e.date)+' · in '+diffDays(T,e.date)+' days'+(e.portion?' · '+esc(e.portion):'')+'</span></span></li>';}).join('')+'</ul></section>';
  return out;
}
function vParentMessages(){
  var changed=false;state.messages.forEach(function(m){if(m.from==='child'&&!m.read){m.read=true;changed=true;}});if(changed)save();
  var out='<section class="hello"><p class="eyebrow">Between Dubai and India</p><h1>Messages</h1></section>';
  out+='<section class="card">'+thread('parent')+'</section>';
  out+='<section class="card"><form class="composer" data-form="pmsg"><fieldset class="rchips"><legend class="sr">Add a stamp</legend><label><input type="radio" name="stamp" value="" checked><span>No stamp</span></label>'+Object.keys(STAMPS).map(function(k){return '<label><input type="radio" name="stamp" value="'+k+'"><span>'+STAMPS[k]+'</span></label>';}).join('')+'</fieldset><div class="comp-row"><label class="sr" for="pm-text">Message</label><textarea id="pm-text" name="text" rows="2" maxlength="400" placeholder="Write to '+esc(C())+'…"></textarea><button class="send" type="submit" aria-label="Send">'+ic('send')+'</button></div></form></section>';
  return out;
}
function vParentFamily(){
  var T=todayStr(),g=state.goals;
  var out='<section class="hello"><p class="eyebrow">Set together</p><h1>Family</h1></section>';
  var pend=state.redemptions.filter(function(r){return r.status==='pending';});
  if(pend.length)out+='<section class="card"><h2>Reward requests</h2><ul class="updates">'+pend.map(function(r){return '<li class="upd cat-star"><span class="upd-ic">'+ic('gift')+'</span><div class="upd-main"><p class="upd-t">'+esc(r.title)+'</p><p class="upd-s">'+r.cost+' points · asked '+relDay(dateOf(r.ts,TZ_C)).toLowerCase()+'</p><div class="upd-a"><button class="btn good" data-act="redeem" data-id="'+r.id+'" data-st="approved">Say yes</button><button class="btn ghost" data-act="redeem" data-id="'+r.id+'" data-st="declined">Not this time</button></div></div></li>';}).join('')+'</ul></section>';
  out+='<section class="card"><h2>Weekly goals</h2><ul class="goalset">'+[['study','Study','study','pencil'],['reading','Reading','read','book'],['active','Sports & screen-free','active','ball']].map(function(r){return '<li class="cat-'+r[2]+'"><span class="goal-l">'+ic(r[3])+r[1]+'</span><span class="stepper"><button data-act="goal" data-k="'+r[0]+'" data-v="-30" aria-label="Less '+r[1]+'">−</button><b>'+fmtMin(g[r[0]])+'</b><button data-act="goal" data-k="'+r[0]+'" data-v="30" aria-label="More '+r[1]+'">+</button></span></li>';}).join('')+'</ul><p class="hint">'+ic('chat','lockc')+'Agree these with '+esc(C())+' on a call. '+esc(C())+' sees the same goals on the Progress tab.</p></section>';
  var lm=state.screen.limit;
  out+='<section class="card"><h2>Screen time limits</h2><ul class="goalset">'+[['school','School days (Mon–Sat)'],['weekend','Sundays']].map(function(r){return '<li class="cat-screen"><span class="goal-l">'+ic('tablet')+r[1]+'</span><span class="stepper"><button data-act="slimit" data-k="'+r[0]+'" data-v="-15" aria-label="Lower '+r[1]+' limit">−</button><b>'+fmtMin(lm[r[0]])+'</b><button data-act="slimit" data-k="'+r[0]+'" data-v="15" aria-label="Raise '+r[1]+' limit">+</button></span></li>';}).join('')+'</ul><p class="hint">'+ic('chat','lockc')+'Agree these with '+esc(C())+'. He sees the same limit and earns 10 points each day he stays within it. TV time isn’t counted, only the iPad.</p></section>';
  var sug=state.tasks.filter(function(t){return t.from==='parent'&&t.date>=T;});
  out+='<section class="card"><h2>Suggest a task</h2>'+(sug.length?'<ul class="tasks">'+sug.map(function(t){return '<li class="'+(t.done?'done':'')+'"><span class="tick ro '+(t.done?'on':'')+'">'+ic('check')+'</span><span class="t-body"><span class="t-title">'+esc(t.title)+'</span><span class="t-meta">'+relDay(t.date)+' · '+(TASKCAT[t.cat]||'Task')+'</span></span><button class="icon-b" data-act="confirm" data-run="delTask" data-id="'+t.id+'" data-text="Remove your suggestion?" aria-label="Remove suggestion">'+ic('x')+'</button></li>';}).join('')+'</ul>':'')+taskForm('ptask')+'</section>';
  out+='<section class="card"><div class="card-h"><h2>Family rewards</h2><button class="tiny" data-act="sheet" data-s="reward">Add</button></div><ul class="rewards">'+state.rewards.map(function(r){return '<li class="rw"><span class="rw-cost">'+ic('star','fill')+r.cost+'</span><span class="rw-t">'+esc(r.title)+'</span><button class="tiny" data-act="sheet" data-s="reward" data-id="'+r.id+'">Edit</button></li>';}).join('')+'</ul><p class="hint">'+ic('star')+esc(C())+' has '+balance()+' points right now.</p></section>';
  var nl=[['reward','Tell me when '+C()+' asks for a reward'],['exam','A test is less than a week away'],['screen','Screen time goes over the limit'],['mood','A check-in says sad or frustrated'],['milestone','Streaks and finished books'],['weekly','Sunday weekly summary']];
  out+='<section class="card"><h2>School</h2><div class="school-row"><b>'+esc(SCHOOL.name)+'</b><span class="muted">Grade '+SCHOOL.grade+' · Monday to Saturday · classes '+fmtTime(PERIODS[0][0])+' to '+fmtTime(PERIODS[6][1])+'</span></div>'+schoolLink('btn ghost wide','Open school homework')+'<p class="hint">'+ic('lock','lockc')+'Opens the school’s own website. Log in once on each device and Safari remembers it.</p></section>';
  out+='<section class="card"><h2>Updates I get</h2><div class="switches">'+nl.map(function(x){return '<label class="switch" for="nt-'+x[0]+'"><span>'+esc(x[1])+'</span><input type="checkbox" id="nt-'+x[0]+'" data-notify="'+x[0]+'" '+(state.notify[x[0]]?'checked':'')+'></label>';}).join('')+'</div><p class="hint">'+ic('bell','lockc')+'No alerts for unfinished tasks. Those are '+esc(C())+'’s to manage.</p></section>';
  out+='<section class="card"><h2>Names</h2><form class="form" data-form="names"><div class="row2"><div class="field"><label class="lab" for="nm-c">Child’s name</label><input id="nm-c" name="child" maxlength="20" value="'+esc(state.family.child)+'"></div><div class="field"><label class="lab" for="nm-p">What '+esc(C())+' calls you</label><input id="nm-p" name="parent" maxlength="20" value="'+esc(state.family.parent)+'"></div></div><button class="btn ghost wide" type="submit">Save names</button></form></section>';
  out+='<section class="card promise"><h2>'+ic('shield')+' What this app never collects</h2><ul><li>Location</li><li>Websites he visits, or what he watches or types</li><li>Chats, photos or contacts on '+esc(C())+'’s phone</li><li>Mood notes '+esc(C())+' keeps private</li></ul><p class="hint" style="color:var(--ink-2)">'+esc(C())+' sees exactly what you see, including his screen time, and can delete any log he made.</p></section>';
  out+=pushCard('parent',false);
  out+=childLoginCard();
  out+=accountCard();
  return out;
}
function taskForm(kind){
  return '<form class="form" data-form="'+kind+'"><div class="field"><label class="lab" for="tk-title">'+(kind==='ptask'?'Task for '+esc(C()):'Task')+'</label><input id="tk-title" name="title" maxlength="80" autocomplete="off" placeholder="'+(kind==='ptask'?'e.g. Call Granny after dinner':'e.g. Maths: Ex 5.2, Q1–8')+'"></div>'+
    '<fieldset class="field"><legend class="lab">Type</legend><div class="rchips">'+Object.keys(TASKCAT).map(function(k,i){return '<label><input type="radio" name="cat" value="'+k+'" '+(i===(kind==='ptask'?2:0)?'checked':'')+'><span>'+TASKCAT[k]+'</span></label>';}).join('')+'</div></fieldset>'+
    '<fieldset class="field"><legend class="lab">Day</legend><div class="seg2"><label><input type="radio" name="day" value="today" checked><span>Today</span></label><label><input type="radio" name="day" value="tomorrow"><span>Tomorrow</span></label></div></fieldset>'+
    '<button class="btn '+(kind==='ptask'?'ghost':'primary')+' wide" type="submit">'+(kind==='ptask'?'Suggest to '+esc(C()):'Add task')+'</button></form>';
}

/* ---------- sheets ---------- */
function whenField(){return '<fieldset class="field"><legend class="lab">When</legend><div class="seg2"><label><input type="radio" name="when" value="today" checked><span>Today</span></label><label><input type="radio" name="when" value="yesterday"><span>Yesterday</span></label></div></fieldset>';}
function minField(id,val,chips){return '<div class="field"><label class="lab" for="'+id+'">Minutes</label><div class="minrow"><input id="'+id+'" name="min" type="number" inputmode="numeric" min="5" max="300" step="5" value="'+val+'">'+chips.map(function(v){return '<button type="button" class="chip" data-act="setval" data-t="'+id+'" data-v="'+v+'">'+v+'</button>';}).join('')+'</div></div>';}
function remindField(rem){
  return '<fieldset class="field"><legend class="lab">Remind '+esc(C())+'</legend><div class="rchips">'+[[7,'A week before'],[3,'3 days before'],[1,'The day before'],[0,'On the day']].map(function(r){return '<label><input type="checkbox" name="remind" value="'+r[0]+'"'+(rem.indexOf(r[0])>-1?' checked':'')+'><span>'+r[1]+'</span></label>';}).join('')+'</div></fieldset><p class="hint">'+ic('bell','lockc')+'Reminders show on '+esc(C())+'’s Today screen and arrive as notifications.</p>';
}
function speakReview(){
  var sp=ui.speak,n=sp.items.length;
  return '<p class="heard">“'+esc(sp.text)+'”</p>'+(sp.yday?'<p class="hint">'+ic('clock','lockc')+'These will be saved for yesterday.</p>':'')+
  '<form class="form" data-form="speakSave"><ul class="parsed">'+sp.items.map(function(it,q){
    var head,sub='',ins='',cc,icn;
    if(it.type==='study'){head='Study';cc='study';icn='pencil';sub=[it.topic,it.hw?'Homework done':''].filter(Boolean).join(' · ');
      ins='<label class="wide" for="pz-subj-'+q+'">Subject <select id="pz-subj-'+q+'" name="subj-'+q+'">'+SUBJECTS.map(function(x){return '<option'+(x===it.subject?' selected':'')+'>'+x+'</option>';}).join('')+'</select></label>';}
    else if(it.type==='reading'){head='Reading';cc='read';icn='book';sub=it.note?'“'+it.note+'”':'';
      ins='<label class="wide" for="pz-book-'+q+'">Book <select id="pz-book-'+q+'" name="book-'+q+'">'+state.books.map(function(b){return '<option value="'+b.id+'"'+(b.id===it.bookId?' selected':'')+'>'+esc(b.title)+'</option>';}).join('')+'</select></label><label for="pz-pages-'+q+'">Pages <input id="pz-pages-'+q+'" name="pages-'+q+'" type="number" inputmode="numeric" min="1" max="500" value="'+(it.pages||'')+'"></label>';}
    else {var k=KINDS[it.kind]||KINDS.outdoor;head=it.what;sub=k.l;cc=it.kind==='creative'?'create':'active';icn=k.i;}
    ins+='<label for="pz-min-'+q+'">Minutes <input id="pz-min-'+q+'" name="min-'+q+'" type="number" inputmode="numeric" min="1" max="300" value="'+(it.min||'')+'"></label>';
    var miss=(!it.min||(it.type==='reading'&&!it.pages))?'<span class="pill wait">Fill in the empty box</span>':'';
    return '<li class="pz cat-'+cc+'"><span class="h-ic">'+ic(icn)+'</span><div class="pz-main"><b>'+esc(head)+'</b>'+(sub?'<small>'+esc(sub)+'</small>':'')+miss+'<div class="pz-in">'+ins+'</div></div><button type="button" class="icon-b" data-act="pzRemove" data-i="'+q+'" aria-label="Remove this one">'+ic('x')+'</button></li>';
  }).join('')+'</ul><button class="btn primary wide" type="submit">'+(n===1?'Save it':'Save all '+n)+'</button></form><button class="linkish" data-act="speakAgain">'+ic('mic')+'Say it again</button>';
}
function syncSpeak(){
  var f=document.querySelector('form[data-form="speakSave"]');if(!f||!ui.speak)return;var fd=new FormData(f);
  ui.speak.items.forEach(function(it,q){var v=fd.get('min-'+q);if(v!=null)it.min=clampInt(v,0,300);if(it.type==='reading'){var pv=fd.get('pages-'+q);if(pv!=null)it.pages=clampInt(pv,0,500);var bv=fd.get('book-'+q);if(bv)it.bookId=bv;}if(it.type==='study'){var sv=fd.get('subj-'+q);if(sv)it.subject=sv;}});
}
function sheetContent(p){
  var T=todayStr(),i;
  switch(p.s){
  case 'speak':
    if(p.stage==='review'&&ui.speak&&ui.speak.items.length)return {t:'Check and save',b:speakReview()};
    return {t:'Say what you did',b:'<div class="mic-hint"><span class="mic">'+ic('mic')+'</span><p>Tap the box, then tap the <b>microphone</b> on the keyboard and speak. Say how long, like “for 30 minutes”.</p></div><form class="form" data-form="speak"><div class="field"><label class="lab" for="sp-text">What did you do?</label><textarea id="sp-text" name="text" rows="4" maxlength="600" placeholder="I read Malgudi Schooldays for 20 minutes, 12 pages…">'+esc(ui.speak?ui.speak.text:'')+'</textarea></div><div class="field"><span class="lab">Or try an example</span><div class="says">'+['I read Malgudi Schooldays for 20 minutes, 12 pages. I liked the part where Swami and Rajam become friends.','Studied maths fractions for 45 minutes and my homework is done','Played cricket for one hour, then drawing for half an hour'].map(function(x){return '<button type="button" class="ex-say" data-act="setval" data-t="sp-text" data-v="'+esc(x)+'">“'+esc(x)+'”</button>';}).join('')+'</div></div><button class="btn primary wide" type="submit">Check what I said</button></form>'};
  case 'log':
    return {t:'What did you do?',b:'<div class="choose">'+[['speak','Say it','mic','study','Speak in your own words and the app fills it in'],['log-study','Study','pencil','study','Subject, minutes, homework'],['log-reading','Reading','book','read','Book, pages, what you learned'],['log-activity','Sports & screen-free','ball','active','Practice, play, creative time'],['task-add','Add a task','check','good','Homework, chores, to-dos'],['screen','Screen time','tablet','screen','Today’s iPad total']].map(function(r){return '<button class="choice cat-'+r[3]+'" data-act="sheet" data-s="'+r[0]+'"><span class="choice-ic">'+ic(r[2])+'</span><span class="choice-txt"><b>'+r[1]+'</b><small>'+r[4]+'</small></span>'+ic('chev','chev')+'</button>';}).join('')+'</div>'};
  case 'log-study':
    var w=wd(T),todays=isSchoolDate(T)?(state.timetable[w]||[]):[];var pre='Maths';for(i=0;i<todays.length;i++){var sj=subjOfPeriod(todays[i]);if(sj){pre=sj;break;}}
    return {t:'Log study time',b:'<form class="form" data-form="study">'+whenField()+'<div class="field"><label class="lab" for="f-subj">Subject</label><select id="f-subj" name="subject">'+SUBJECTS.map(function(x){return '<option'+(x===pre?' selected':'')+'>'+x+'</option>';}).join('')+'</select></div>'+minField('f-min',30,[15,30,45,60])+'<div class="field"><label class="lab" for="f-topic">What did you work on?</label><input id="f-topic" name="topic" maxlength="80" autocomplete="off" placeholder="e.g. Fractions, Ex 5.1"></div><label class="check" for="f-hw"><input type="checkbox" id="f-hw" name="hw"><span>Homework for this subject is done</span></label><p class="hint">'+ic('star','fill')+'10 points, or 15 when you study for 45 minutes or more.</p><button class="btn primary wide" type="submit">Save study time</button></form>'};
  case 'log-reading':
    var cur=state.books.filter(function(b){return b.read<b.total;});
    return {t:'Log reading',b:'<form class="form" data-form="reading">'+whenField()+'<div class="field"><label class="lab" for="f-book">Book</label><select id="f-book" name="book">'+cur.map(function(b){return '<option value="'+b.id+'">'+esc(b.title)+' (p. '+b.read+' of '+b.total+')</option>';}).join('')+'<option value="__new"'+(cur.length?'':' selected')+'>A new book…</option></select></div><div id="newbook" class="form"'+(cur.length?' hidden':'')+'><div class="field"><label class="lab" for="f-btitle">Book title</label><input id="f-btitle" name="btitle" maxlength="80" autocomplete="off"></div><div class="row2"><div class="field"><label class="lab" for="f-bauthor">Author</label><input id="f-bauthor" name="bauthor" maxlength="60" autocomplete="off"></div><div class="field"><label class="lab" for="f-btotal">Total pages</label><input id="f-btotal" name="btotal" type="number" inputmode="numeric" min="5" max="2000" value="120"></div></div></div><div class="field"><label class="lab" for="f-pages">Pages read</label><div class="minrow"><input id="f-pages" name="pages" type="number" inputmode="numeric" min="1" max="500" value="10">'+[5,10,15,20].map(function(v){return '<button type="button" class="chip" data-act="setval" data-t="f-pages" data-v="'+v+'">'+v+'</button>';}).join('')+'</div></div>'+minField('f-rmin',20,[10,15,20,30])+'<div class="field"><label class="lab" for="f-note">One thing you learned or liked</label><textarea id="f-note" name="note" maxlength="200" placeholder="Something that happened, a new word, or what you think happens next"></textarea></div><p class="hint">'+ic('star','fill')+'10 points, plus 5 when you write what you learned.</p><button class="btn primary wide" type="submit">Save reading</button></form>'};
  case 'log-activity':
    return {t:'Sports & screen-free time',b:'<form class="form" data-form="activity">'+whenField()+'<fieldset class="field"><legend class="lab">What kind?</legend><div class="rchips">'+Object.keys(KINDS).map(function(k,j){return '<label><input type="radio" name="kind" value="'+k+'"'+(j===0?' checked':'')+'><span>'+ic(KINDS[k].i)+KINDS[k].l+'</span></label>';}).join('')+'</div></fieldset><div class="field"><label class="lab" for="f-what">What did you do?</label><input id="f-what" name="what" list="act-sugg" maxlength="60" autocomplete="off" placeholder="e.g. Cricket practice"><datalist id="act-sugg">'+['Cricket practice','Badminton','Football with friends','Cycling','Skating','Swimming','Skipping','Yoga','Drawing','Harmonium practice','Carrom','Board games','Lego','Helping in the kitchen'].map(function(x){return '<option value="'+x+'">';}).join('')+'</datalist></div>'+minField('f-amin',30,[15,30,45,60])+'<p class="hint">'+ic('star','fill')+'10 points for every activity you log.</p><button class="btn primary wide" type="submit">Save activity</button></form>'};
  case 'task-add':
    return {t:'Add a task',b:taskForm('task')+'<p class="hint">'+ic('school','lockc')+'<span>New homework from school? Open it, then add it here. '+schoolLink('linkish','School homework')+'</span></p>'};
  case 'mood':
    var cm=state.moods[T]||{},f=p.face||cm.face||'happy';
    return {t:'How are you feeling?',b:'<form class="form" data-form="mood"><fieldset class="field"><legend class="sr">Mood</legend><div class="faces">'+Object.keys(MOODS).map(function(k){return '<label class="facepick"><input type="radio" name="face" value="'+k+'"'+(k===f?' checked':'')+'><span class="fp">'+face(k,46)+'<b>'+MOODS[k]+'</b></span></label>';}).join('')+'</div></fieldset><div class="field"><label class="lab" for="f-mnote">Want to say why? (optional)</label><textarea id="f-mnote" name="note" maxlength="200" placeholder="Anything on your mind">'+esc(cm.note||'')+'</textarea></div><label class="check" for="f-share"><input type="checkbox" id="f-share" name="share"'+(cm.share?' checked':'')+'><span>Share this note with '+esc(P())+'</span></label><p class="hint">'+ic('lock','lockc')+esc(P())+' sees how you feel. Your note stays private unless you tick the box.</p><button class="btn primary wide" type="submit">Save check-in</button></form>'};
  case 'messages':
    return {t:'Messages with '+esc(P()),b:thread('child')+'<form class="composer" data-form="cmsg"><div class="chips">'+['Thank you!','Love you','Can we call tonight?','I did it!'].map(function(c){return '<button type="button" class="chip" data-act="setval" data-t="cm-text" data-v="'+esc(c)+'">'+esc(c)+'</button>';}).join('')+'</div><div class="comp-row"><label class="sr" for="cm-text">Message</label><textarea id="cm-text" name="text" rows="2" maxlength="400" placeholder="Write to '+esc(P())+'…"></textarea><button class="send" type="submit" aria-label="Send">'+ic('send')+'</button></div></form>'};
  case 'see':
    return {t:'What '+esc(P())+' can see',b:'<ul class="seelist yes">'+['Your tasks and which ones are done','Study, reading and activities you log, including book notes','Your mood face each day','Your points, streaks, stamps and reward requests','Your plan and upcoming tests','Your iPad screen time total for each day','Messages you send'].map(function(x){return '<li>'+ic('check')+'<span>'+x+'</span></li>';}).join('')+'</ul><h2>Never shared</h2><ul class="seelist no">'+['Mood notes you keep private','Where you are','Websites you visit, what you watch, chats or photos','Anything you don’t log yourself'].map(function(x){return '<li>'+ic('x')+'<span>'+x+'</span></li>';}).join('')+'</ul><p class="hint">'+ic('trash','lockc')+'You can delete any log from Progress, History.</p>'};
  case 'block':
    var d=p.d||T,bl=p.id?getPlan(d).filter(function(x){return x.id===p.id;})[0]:null;
    return {t:bl?'Edit plan':'Add to plan',b:'<form class="form" data-form="block" data-d="'+d+'"'+(bl?' data-id="'+bl.id+'"':'')+'><div class="field"><label class="lab" for="b-title">What</label><input id="b-title" name="title" maxlength="60" autocomplete="off" value="'+(bl?esc(tt(bl.title)):esc(p.title||''))+'" placeholder="e.g. Science revision"></div><div class="row2"><div class="field"><label class="lab" for="b-start">Starts</label><input id="b-start" name="start" type="time" value="'+(bl?bl.start:'16:00')+'"></div><div class="field"><label class="lab" for="b-end">Ends (optional)</label><input id="b-end" name="end" type="time" value="'+(bl?bl.end:'')+'"></div></div><div class="field"><label class="lab" for="b-cat">Type</label><select id="b-cat" name="cat">'+Object.keys(CAT).map(function(k){return '<option value="'+k+'"'+((bl?bl.cat:(p.cat||'study'))===k?' selected':'')+'>'+CAT[k].l+'</option>';}).join('')+'</select></div><p class="hint">'+ic('plan','lockc')+'Changes '+(relDay(d)==='Today'?'today':relDay(d)==='Tomorrow'?'tomorrow':fmtShort(d))+' only.</p><div class="btnrow">'+(bl?'<button type="button" class="btn danger" data-act="delBlock" data-d="'+d+'" data-id="'+bl.id+'">Remove</button>':'')+'<button class="btn primary" type="submit">Save</button></div></form>'};
  case 'exam':
    var ex=p.id?state.exams.filter(function(x){return x.id===p.id;})[0]:null;
    return {t:ex?'Edit test':'Add a test',b:'<form class="form" data-form="exam"'+(ex?' data-id="'+ex.id+'"':'')+'><div class="row2"><div class="field"><label class="lab" for="e-subj">Subject</label><select id="e-subj" name="subject">'+SUBJECTS.map(function(x){return '<option'+((ex?ex.subject:'Maths')===x?' selected':'')+'>'+x+'</option>';}).join('')+'</select></div><div class="field"><label class="lab" for="e-kind">Kind</label><select id="e-kind" name="kind">'+EXAMKINDS.map(function(x){return '<option'+((ex?ex.kind:'Unit test')===x?' selected':'')+'>'+x+'</option>';}).join('')+'</select></div></div><div class="field"><label class="lab" for="e-date">Date</label><input id="e-date" name="date" type="date" min="'+T+'" value="'+(ex?ex.date:addDays(T,7))+'"></div><div class="field"><label class="lab" for="e-portion">Portion</label><input id="e-portion" name="portion" maxlength="100" autocomplete="off" value="'+(ex?esc(ex.portion||''):'')+'" placeholder="e.g. Ch 4 and 5"></div>'+remindField(ex?(ex.remind||[3,1]):[3,1])+'<div class="btnrow">'+(ex?'<button type="button" class="btn danger" data-act="delExam" data-id="'+ex.id+'">Remove</button>':'')+'<button class="btn primary" type="submit">Save</button></div></form>'};
  case 'tt':
    var ww=+p.w,per=state.timetable[ww]||[];
    return {t:DOWL[ww]+' timetable',b:'<form class="form" data-form="tt" data-w="'+ww+'"><div class="row2">'+[0,1,2,3,4,5,6].map(function(k){return '<div class="field"><label class="lab" for="tt-'+k+'">'+ROMAN[k]+' · '+fmtTime(PERIODS[k][0])+'</label><input id="tt-'+k+'" name="p'+k+'" maxlength="24" value="'+esc(per[k]||'')+'"></div>';}).join('')+'</div><button class="btn primary wide" type="submit">Save timetable</button></form>'};
  case 'reward':
    var rw=p.id?state.rewards.filter(function(x){return x.id===p.id;})[0]:null;
    return {t:rw?'Edit reward':'Add a reward',b:'<form class="form" data-form="reward"'+(rw?' data-id="'+rw.id+'"':'')+'><div class="field"><label class="lab" for="r-title">Reward</label><input id="r-title" name="title" maxlength="60" autocomplete="off" value="'+(rw?esc(rw.title):'')+'" placeholder="e.g. Choose Sunday breakfast"></div><div class="field"><label class="lab" for="r-cost">Points</label><div class="minrow"><input id="r-cost" name="cost" type="number" inputmode="numeric" min="10" max="2000" step="10" value="'+(rw?rw.cost:100)+'">'+[50,100,200,300].map(function(v){return '<button type="button" class="chip" data-act="setval" data-t="r-cost" data-v="'+v+'">'+v+'</button>';}).join('')+'</div></div><p class="hint">'+ic('family','lockc')+'Decide rewards together so they feel fair. Experiences and time together tend to work better than things.</p><div class="btnrow">'+(rw?'<button type="button" class="btn danger" data-act="delReward" data-id="'+rw.id+'">Remove</button>':'')+'<button class="btn primary" type="submit">Save</button></div></form>'};
  case 'screen':
    var sdd=p.d||'',sx=sdd?scrDay(sdd):null,sm=sx?scrTotal(sdd):0;
    return {t:'iPad screen time',b:'<form class="form" data-form="screen"'+(sdd?' data-d="'+sdd+'"':'')+'>'+(sdd?'<p class="muted">'+fmtLong(sdd)+'</p>':whenField())+'<p class="hint">'+ic('tablet','lockc')+'<span>'+screenHow(ui.mode)+'</span></p><div class="row2"><div class="field"><label class="lab" for="sc-h">Hours</label><input id="sc-h" name="h" type="number" inputmode="numeric" min="0" max="16" value="'+Math.floor(sm/60)+'"></div><div class="field"><label class="lab" for="sc-m">Minutes</label><input id="sc-m" name="m" type="number" inputmode="numeric" min="0" max="59" value="'+(sm%60)+'"></div></div><p class="muted">Limit: '+(sdd?limitText(sdd):limitText(T))+'</p><div class="btnrow">'+(sx?'<button type="button" class="btn danger" data-act="delScreen" data-d="'+sdd+'">Remove</button>':'')+'<button class="btn primary" type="submit">Save</button></div></form>'};
  case 'confirm':
    return {t:'Are you sure?',b:'<p>'+esc(p.text||'')+'</p><div class="btnrow"><button class="btn ghost" data-act="close">Cancel</button><button class="btn primary" data-act="yes">Yes</button></div>'};
  }
  return {t:'',b:''};
}
function renderSheet(){
  var root=$('#sheet-root');
  if(!ui.sheet){root.hidden=true;root.innerHTML='';document.body.classList.remove('locked');return;}
  if(ui.sheet.s==='messages'){var ch=false;state.messages.forEach(function(m){if(m.from==='parent'&&!m.read){m.read=true;ch=true;}});if(ch)save();}
  var c=sheetContent(ui.sheet);
  root.innerHTML='<div class="scrim" data-act="close"></div><div class="sheet" role="dialog" aria-modal="true" aria-labelledby="sh-t"><div class="grab"></div><div class="sheet-h"><h2 id="sh-t" tabindex="-1">'+c.t+'</h2><button class="icon-b" data-act="close" aria-label="Close">'+ic('x')+'</button></div><div class="sheet-b">'+c.b+'</div></div>';
  root.hidden=false;document.body.classList.add('locked');
  var h=$('#sh-t');if(h)h.focus({preventScroll:true});
  if(ui.sheet.s==='speak'&&ui.sheet.stage!=='review'){var ta=$('#sp-text');if(ta)ta.focus({preventScroll:true});}
  if(ui.sheet.s==='messages'){var sh=root.querySelector('.sheet');var th=root.querySelector('.thread');if(sh&&th)sh.scrollTop=th.scrollHeight;}
}
function openSheet(p){ui.sheet=p;renderSheet();}
function closeSheet(){ui.sheet=null;renderSheet();render();}

/* ---------- render ---------- */
var CHILD_TABS=[['today','Today','today'],['plan','Plan','plan'],['log','Log','plus'],['progress','Progress','progress'],['rewards','Rewards','gift']];
var PARENT_TABS=[['overview','Today','home'],['week','Week','week'],['messages','Messages','chat'],['family','Family','family']];
function header(){
  return '<header class="top"><div class="top-in"><div class="brand"><b>Growth Companion</b><small>'+(me&&me.role==='parent'?esc(P())+'’s view':esc(C())+'’s view')+'</small></div><span class="sync" role="status"></span></div></header>';
}
function nav(){
  var tabs=ui.mode==='child'?CHILD_TABS:PARENT_TABS,cur=ui.tab[ui.mode];
  return '<nav class="nav" aria-label="Sections"><div class="nav-in" style="--n:'+tabs.length+'">'+tabs.map(function(t){
    if(t[0]==='log')return '<button data-act="sheet" data-s="log" aria-label="Log something"><span class="plus-w">'+ic('plus')+'</span>Log</button>';
    var b='';if(ui.mode==='parent'&&t[0]==='messages'){var n=unread('child');if(n)b='<span class="badge">'+n+'</span>';}
    if(ui.mode==='child'&&t[0]==='today'){var n2=unread('parent');if(n2)b='<span class="badge">'+n2+'</span>';}
    return '<button class="'+(cur===t[0]?'on':'')+'" data-act="tab" data-tab="'+t[0]+'"'+(cur===t[0]?' aria-current="page"':'')+'>'+ic(t[2])+t[1]+b+'</button>';
  }).join('')+'</div></nav>';
}
function render(){
  if(ui.screen!=='app'){
    $('#app').innerHTML=ui.screen==='noconfig'?vNoConfig():ui.screen==='auth'?vAuth():ui.screen==='setup'?vSetup():ui.screen==='recovery'?vRecovery():vLoading();
    return;
  }
  var m=ui.mode,t=ui.tab[m],body;
  if(m==='child')body=t==='plan'?vChildPlan():t==='progress'?vChildProgress():t==='rewards'?vChildRewards():vChildToday();
  else body=t==='week'?vParentWeek():t==='messages'?vParentMessages():t==='family'?vParentFamily():vParentOverview();
  $('#app').innerHTML=header()+'<main class="main" id="main">'+body+'</main>'+nav();
}
var toastTimer=null;
function toast(msg){var el=$('#toast');el.textContent=msg;el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.hidden=true;},2600);}

/* ---------- actions ---------- */
function run(name,id){
  if(name==='delTask'){state.tasks=state.tasks.filter(function(t){return t.id!==id;});toast('Task removed');}
  else if(name==='delLog'){state.logs=state.logs.filter(function(l){return l.id!==id;});toast('Log deleted');}
  else if(name==='signout'){signOutNow();return;}
  save();
}
function sendMsg(from,text,stamp,kind,date){var m={id:uid(),from:from,kind:kind||'note',date:date||todayStr(),ts:Date.now(),text:text,read:false};if(stamp)m.stamp=stamp;state.messages.push(m);save();}

document.addEventListener('click',function(e){
  var el=e.target.closest('[data-act]');if(!el)return;
  var a=el.dataset.act,T=todayStr(),x;
  switch(a){
  case 'tab':ui.tab[ui.mode]=el.dataset.tab;saveUI();if(ui.sheet){ui.sheet=null;renderSheet();}render();window.scrollTo(0,ui.mode==='parent'&&el.dataset.tab==='messages'?document.body.scrollHeight:0);break;
  case 'sheet':if(el.dataset.s==='speak')ui.speak=null;openSheet(Object.assign({},el.dataset));break;
  case 'pzRemove':if(ui.speak&&ui.sheet){syncSpeak();ui.speak.items.splice(+el.dataset.i,1);if(!ui.speak.items.length)ui.sheet.stage='input';renderSheet();}break;
  case 'speakAgain':if(ui.sheet){syncSpeak();ui.sheet.stage='input';renderSheet();}break;
  case 'close':closeSheet();break;
  case 'setval':x=document.getElementById(el.dataset.t);if(x){x.value=el.dataset.v;x.focus();}break;
  case 'toggleTask':x=state.tasks.filter(function(t){return t.id===el.dataset.id;})[0];if(x){x.done=!x.done;save();render();toast(x.done?'Done! +5 points':'Marked not done');}break;
  case 'moveLeft':state.tasks.forEach(function(t){if(t.date===addDays(T,-1)&&!t.done)t.date=T;});save();render();toast('Moved to today');break;
  case 'planDay':ui.planDay=el.dataset.d;render();break;
  case 'pday':ui.pday=+el.dataset.v;render();break;
  case 'holiday':x=el.dataset.d;if(!state.holidays)state.holidays={};if(state.holidays[x])delete state.holidays[x];else state.holidays[x]=true;delete state.plans[x];save();render();toast(state.holidays[x]?'Marked as a holiday':'Back to a school day');break;
  case 'resetPlan':delete state.plans[el.dataset.d];save();render();toast('Back to the usual routine');break;
  case 'saveRoutine':x=el.dataset.d;var key=isSchoolDate(x)?'school':'weekend';state.template[key]=sortPlan(state.plans[x]).map(function(b){return Object.assign({},b);});delete state.plans[x];save();render();toast('Saved as your usual '+(key==='school'?'school-day':'day-off')+' plan');break;
  case 'delBlock':x=editPlan(el.dataset.d);state.plans[el.dataset.d]=x.filter(function(b){return b.id!==el.dataset.id;});save();ui.sheet=null;renderSheet();render();toast('Removed from plan');break;
  case 'delExam':state.exams=state.exams.filter(function(t){return t.id!==el.dataset.id;});save();ui.sheet=null;renderSheet();render();toast('Test removed');break;
  case 'delReward':state.rewards=state.rewards.filter(function(t){return t.id!==el.dataset.id;});save();ui.sheet=null;renderSheet();render();toast('Reward removed');break;
  case 'ask':x=state.rewards.filter(function(r){return r.id===el.dataset.id;})[0];if(x&&balance()>=x.cost){state.redemptions.push({id:uid(),rewardId:x.id,title:x.title,cost:x.cost,status:'pending',ts:Date.now()});save();render();toast('Sent to '+P());}break;
  case 'redeem':x=state.redemptions.filter(function(r){return r.id===el.dataset.id;})[0];if(x){x.status=el.dataset.st;if(x.status==='approved')sendMsg('parent','Yes to “'+x.title+'”! You earned it.','welldone');save();render();toast(x.status==='approved'?'Approved and '+C()+' is told':'Points returned to '+C());}break;
  case 'slimit':x=el.dataset.k;state.screen.limit[x]=Math.max(15,Math.min(600,state.screen.limit[x]+(+el.dataset.v)));save();render();break;
  case 'goal':x=el.dataset.k;state.goals[x]=Math.max(30,Math.min(1200,state.goals[x]+(+el.dataset.v)));save();render();break;
  case 'cheer':sendMsg('parent',el.dataset.text,el.dataset.stamp||'');render();toast('Sent to '+C());break;
  case 'authRole':ui.auth={role:el.dataset.v,mode:'signin'};render();break;
  case 'authBack':ui.auth=ui.auth.mode==='forgot'?{role:'parent',mode:'signin'}:{role:null,mode:'signin'};render();break;
  case 'authMode':ui.auth.mode=el.dataset.m;render();break;
  case 'setupSkip':ui.setupStep=3;render();break;
  case 'setupDone':enterApp();break;
  case 'pushOn':enablePush();break;
  case 'pushTest':API.testPush().then(function(){toast('Test sent. It should arrive within a minute.');}).catch(function(e){toast(friendly(e));});break;
  case 'dismiss':setDismissed(el.dataset.k);render();break;
  case 'delScreen':delete state.screen.days[el.dataset.d];save();ui.sheet=null;renderSheet();render();toast('Screen time removed');break;
  case 'confirm':openSheet({s:'confirm',text:el.dataset.text,run:el.dataset.run,id:el.dataset.id});break;
  case 'yes':x=ui.sheet;ui.sheet=null;renderSheet();if(x)run(x.run,x.id);render();break;
  }
});
document.addEventListener('change',function(e){
  var t=e.target;
  if(t.id==='f-book'){var nb=document.getElementById('newbook');if(nb)nb.hidden=t.value!=='__new';}
  if(t.dataset&&t.dataset.notify){state.notify[t.dataset.notify]=t.checked;save();toast(t.checked?'Turned on':'Turned off');}
});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&ui.sheet)closeSheet();});
document.addEventListener('submit',function(e){
  var f=e.target.closest('form[data-form]');if(!f)return;e.preventDefault();
  var fd=new FormData(f);function g(k){return String(fd.get(k)==null?'':fd.get(k)).trim();}
  var T=todayStr(),when=g('when')==='yesterday'?addDays(T,-1):T,ts=when===T?Date.now():tsC(when,'19:00'),x,min,pts;
  switch(f.dataset.form){
  case 'study':
    min=clampInt(g('min'),5,300);if(!min)return toast('Add how many minutes you studied');
    x={id:uid(),type:'study',date:when,ts:ts,subject:g('subject')||'Other',min:min,topic:g('topic'),hw:fd.get('hw')==='on'};state.logs.push(x);save();closeSheet();toast('Saved! +'+logPts(x)+' points');break;
  case 'reading':
    var bid=g('book'),bk=null;
    if(bid==='__new'){var title=g('btitle');if(!title)return toast('Add the book’s title');bk={id:uid(),ts:Date.now(),title:title,author:g('bauthor'),total:clampInt(g('btotal'),5,2000)||120,read:0,finishedOn:null};state.books.push(bk);}else bk=bookById(bid);
    if(!bk)return toast('Choose a book');
    var pg=clampInt(g('pages'),1,500);if(!pg)return toast('Add how many pages you read');
    min=clampInt(g('min'),1,300)||15;
    bk.read=Math.min(bk.total,bk.read+pg);var fin=false;if(bk.read>=bk.total&&!bk.finishedOn){bk.finishedOn=when;fin=true;}
    x={id:uid(),type:'reading',date:when,ts:ts,bookId:bk.id,pages:pg,min:min,note:g('note')};state.logs.push(x);save();closeSheet();toast(fin?'You finished '+bk.title+'! +'+logPts(x):'Saved! +'+logPts(x)+' points');break;
  case 'activity':
    min=clampInt(g('min'),5,300);if(!min)return toast('Add how many minutes');
    var kind=g('kind')||'outdoor';x={id:uid(),type:'activity',date:when,ts:ts,kind:kind,what:g('what')||KINDS[kind].l,min:min};state.logs.push(x);save();closeSheet();toast('Saved! +10 points');break;
  case 'task':case 'ptask':
    var tl=g('title');if(!tl)return toast('Write the task first');
    state.tasks.push({id:uid(),ts:Date.now(),date:g('day')==='tomorrow'?addDays(T,1):T,title:tl,cat:g('cat')||'homework',done:false,from:f.dataset.form==='ptask'?'parent':'child'});save();
    if(f.dataset.form==='ptask'){render();toast('Suggested to '+C());}else{closeSheet();toast('Task added');}break;
  case 'mood':
    var fc=g('face')||'happy';state.moods[T]={face:fc,note:g('note'),share:fd.get('share')==='on',ts:Date.now()};save();closeSheet();toast('Thanks for checking in. +2');break;
  case 'cmsg':
    var ct=g('text');if(!ct)return toast('Write a message first');sendMsg('child',ct);renderSheet();toast('Sent to '+P());break;
  case 'pmsg':
    var pt=g('text'),stp=g('stamp');if(!pt&&!stp)return toast('Write a message or pick a stamp');sendMsg('parent',pt||STAMPS[stp],stp);render();window.scrollTo(0,document.body.scrollHeight);toast('Sent to '+C());break;
  case 'remark':
    var rt=g('text');if(!rt)return toast('Write a short remark first');sendMsg('parent',rt,'','remark',f.dataset.d);render();toast('Diary signed');break;
  case 'block':
    var bt=g('title'),bs=g('start');if(!bt||!bs)return toast('Add what and when');
    var plan=editPlan(f.dataset.d);
    if(f.dataset.id){x=plan.filter(function(b){return b.id===f.dataset.id;})[0];if(x){x.title=bt;x.start=bs;x.end=g('end');x.cat=g('cat');}}
    else plan.push({id:uid(),title:bt,start:bs,end:g('end'),cat:g('cat')||'study'});
    save();closeSheet();toast('Plan updated');break;
  case 'speak':
    var stx=g('text');if(!stx)return toast('Say or type what you did first');
    var its=parseSpeech(stx);
    ui.speak={text:stx,items:its,yday:/\byesterday\b/i.test(stx)};
    if(!its.length)return toast('Try saying what you did and for how long');
    ui.sheet.stage='review';renderSheet();break;
  case 'speakSave':
    var list=ui.speak?ui.speak.items:[];if(!list.length)return closeSheet();
    var sd=ui.speak.yday?addDays(T,-1):T,sts=sd===T?Date.now():tsC(sd,'19:00'),made=[];
    for(var q=0;q<list.length;q++){
      var it=list[q],mm=clampInt(g('min-'+q),1,300);
      var lbl=it.type==='study'?'study':it.type==='reading'?'reading':it.what.toLowerCase();
      if(!mm)return toast('Add the minutes for '+lbl);
      if(it.type==='study')made.push({id:uid(),type:'study',date:sd,ts:sts,subject:g('subj-'+q)||it.subject,min:mm,topic:it.topic,hw:it.hw});
      else if(it.type==='reading'){var bk3=bookById(g('book-'+q)),pg3=clampInt(g('pages-'+q),1,500);if(!bk3)return toast('Pick the book');if(!pg3)return toast('Add how many pages you read');made.push({id:uid(),type:'reading',date:sd,ts:sts,bookId:bk3.id,pages:pg3,min:mm,note:it.note});}
      else made.push({id:uid(),type:'activity',date:sd,ts:sts,kind:it.kind,what:it.what,min:mm});
    }
    var psum=0,fin2=null;
    made.forEach(function(l){if(l.type==='reading'){var bb=bookById(l.bookId);bb.read=Math.min(bb.total,bb.read+l.pages);if(bb.read>=bb.total&&!bb.finishedOn){bb.finishedOn=l.date;fin2=bb;}}state.logs.push(l);psum+=logPts(l);});
    ui.speak=null;save();closeSheet();toast((fin2?'You finished '+fin2.title+'! ':'Saved '+made.length+(made.length===1?' log. ':' logs. '))+'+'+psum+' points');break;
  case 'exam':
    var ed=g('date');if(!ed)return toast('Pick the test date');
    var rem=fd.getAll('remind').map(Number);
    if(f.dataset.id){x=state.exams.filter(function(t){return t.id===f.dataset.id;})[0];if(x){x.subject=g('subject');x.kind=g('kind');x.date=ed;x.portion=g('portion');x.remind=rem;}}
    else state.exams.push({id:uid(),subject:g('subject'),kind:g('kind'),date:ed,portion:g('portion'),remind:rem});
    save();closeSheet();toast('Test saved');break;
  case 'tt':
    var arr=[];for(var k=0;k<7;k++)arr.push(g('p'+k));state.timetable[+f.dataset.w]=arr;save();closeSheet();toast('Timetable saved');break;
  case 'reward':
    var rt2=g('title'),rc=clampInt(g('cost'),10,2000);if(!rt2||!rc)return toast('Add a reward and its points');
    if(f.dataset.id){x=state.rewards.filter(function(r){return r.id===f.dataset.id;})[0];if(x){x.title=rt2;x.cost=rc;}}else state.rewards.push({id:uid(),title:rt2,cost:rc});
    save();closeSheet();toast('Reward saved');break;
  case 'names':
    state.family.child=g('child')||state.family.child;state.family.parent=g('parent')||state.family.parent;save();render();toast('Names saved');break;
  case 'screen':
    var sdate=f.dataset.d||when,smin=clampInt(g('h'),0,16)*60+clampInt(g('m'),0,59);
    state.screen.days[sdate]={min:smin,by:ui.mode,ts:Date.now()};save();closeSheet();
    toast(smin>scrLimit(sdate)?'Saved. Over the limit by '+fmtMin(smin-scrLimit(sdate)):'Saved. Within the limit');break;
  case 'login':
    busy(f,API.signIn(g('email'),String(fd.get('pw')||'')).then(enterApp).catch(function(e){toast(authMsg(e));}));break;
  case 'signup':
    if(String(fd.get('pw')||'').length<6)return toast('Use at least 6 characters for the password.');
    busy(f,API.signUp(g('email'),String(fd.get('pw')||'')).then(enterApp).catch(function(e){toast(authMsg(e));}));break;
  case 'childlogin':
    var code=g('code').toUpperCase().replace(/[^A-Z0-9]/g,'');if(code.length!==6)return toast('The family code has 6 letters and numbers.');
    busy(f,API.signInChild(code,String(fd.get('pw')||'')).then(enterApp).catch(function(e){toast(authMsg(e,true));}));break;
  case 'forgot':
    busy(f,API.resetEmail(g('email')).then(function(){toast('Check your email for a link to reset your password.');ui.auth={role:'parent',mode:'signin'};render();}).catch(function(e){toast(authMsg(e));}));break;
  case 'newpass':
    if(String(fd.get('pw')||'').length<6)return toast('Use at least 6 characters for the password.');
    busy(f,API.setPassword(String(fd.get('pw'))).then(function(){toast('Password changed');enterApp();}).catch(function(e){toast(authMsg(e));}));break;
  case 'setup':
    var cn=g('child'),pn=g('parent');if(!cn||!pn)return toast('Fill in both names');
    busy(f,createFamilyFlow(cn,pn).catch(function(e){toast(authMsg(e));}));break;
  case 'childpw':
    var cpw=String(fd.get('pw')||'').trim();if(cpw.length<6)return toast('Use at least 6 letters or numbers.');
    busy(f,API.setChildPassword(cpw).then(function(r){var made=!me.hasChild;me.hasChild=true;if(r&&r.code)me.code=r.code;if(ui.screen==='setup'){ui.setupStep=3;render();}else{render();toast(made?C()+'’s login is ready':'New password saved for '+C());}}).catch(function(e){toast(friendly(e));}));break;
  }
});

/* ---------- boot ---------- */
loadUI();
if(!API){ui.screen='noconfig';render();}
else{
  if('serviceWorker' in navigator){navigator.serviceWorker.register('sw.js').catch(function(){});}
  API.onAuth(function(ev){if(ev==='PASSWORD_RECOVERY'){ui.screen='recovery';render();}});
  enterApp();
}
setInterval(function(){
  document.querySelectorAll('[data-clock]').forEach(function(el){el.textContent=clockIn(el.dataset.clock==='c'?TZ_C:TZ_P);});
},20000);
})();
