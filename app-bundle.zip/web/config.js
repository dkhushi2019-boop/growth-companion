// Filled in automatically when the app is published.
window.GC_CONFIG = null;
