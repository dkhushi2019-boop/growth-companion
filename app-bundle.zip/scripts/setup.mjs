// Runs inside GitHub Actions. Sets up the Supabase project using only the
// SUPABASE_ACCESS_TOKEN secret, then writes web/config.js for the app.
import fs from 'node:fs';
import crypto from 'node:crypto';

const TOKEN = process.env.SUPABASE_ACCESS_TOKEN;
const API = 'https://api.supabase.com/v1';
const SITE = (process.env.PAGES_URL || '').toLowerCase();

function fail(msg) { console.log(`::error::${msg}`); process.exit(1); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const lit = (s) => `'${String(s).replace(/'/g, "''")}'`;

if (!TOKEN) fail('The SUPABASE_ACCESS_TOKEN secret is missing. Add it in GitHub: Settings → Secrets and variables → Actions.');

async function api(path, opt = {}) {
  for (let attempt = 1; ; attempt++) {
    const res = await fetch(API + path, {
      ...opt,
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json', ...(opt.headers || {}) },
    });
    const text = await res.text();
    if (res.ok) return text ? JSON.parse(text) : null;
    if ((res.status === 429 || res.status >= 500) && attempt < 5) { await sleep(3000 * attempt); continue; }
    if (res.status === 401) fail('Supabase did not accept the access token. Make a new token and save it again as SUPABASE_ACCESS_TOKEN.');
    throw new Error(`${opt.method || 'GET'} ${path} → ${res.status}: ${text.slice(0, 500)}`);
  }
}

// 1. Find the project
const projects = await api('/projects');
const wanted = process.env.SUPABASE_PROJECT_REF;
let project = wanted
  ? projects.find((p) => (p.ref || p.id) === wanted)
  : projects.find((p) => /growth.?companion/i.test(p.name)) || (projects.length === 1 ? projects[0] : null);
if (!project) fail(`No Supabase project called "growth-companion" was found. Projects seen: ${projects.map((p) => p.name).join(', ') || 'none'}.`);
const ref = project.ref || project.id;
console.log(`Using Supabase project "${project.name}" (${ref})`);

// 2. Wait until it is ready
for (let i = 0; i < 60; i++) {
  const p = await api(`/projects/${ref}`);
  if (p.status === 'ACTIVE_HEALTHY') break;
  if (/PAUSED|INACTIVE/.test(p.status)) fail('The Supabase project is paused. Open supabase.com, open the project and choose Restore, then run this again.');
  console.log(`Waiting for the project to be ready (${p.status})…`);
  await sleep(10000);
}

const sql = (query) => api(`/projects/${ref}/database/query`, { method: 'POST', body: JSON.stringify({ query }) });

// 3. Browser key (publishable if available, otherwise the classic anon key)
const keys = await api(`/projects/${ref}/api-keys?reveal=true`);
const browserKey = (keys.find((k) => k.type === 'publishable') || keys.find((k) => k.name === 'anon') || {}).api_key;
if (!browserKey) fail('Could not read the project’s public key.');

// 4. Sign-in settings: no confirmation emails, links point to the app
await api(`/projects/${ref}/config/auth`, {
  method: 'PATCH',
  body: JSON.stringify({ site_url: SITE, uri_allow_list: SITE ? `${SITE}**` : '', mailer_autoconfirm: true, password_min_length: 6 }),
});
console.log('Sign-in settings updated');

// 5. Database
await sql(fs.readFileSync('supabase/sql/schema.sql', 'utf8'));
console.log('Database ready');

// 6. Server settings and notification keys (kept in the database, never in the code)
const have = Object.fromEntries((await sql('select key, value from public.app_config')).map((r) => [r.key, r.value]));
const put = { functions_url: `https://${ref}.supabase.co/functions/v1`, site_url: SITE };
if (!have.cron_secret) put.cron_secret = crypto.randomBytes(24).toString('hex');
if (!have.vapid_private_jwk || !have.vapid_public) {
  const kp = await crypto.webcrypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  put.vapid_private_jwk = JSON.stringify(await crypto.webcrypto.subtle.exportKey('jwk', kp.privateKey));
  put.vapid_public = Buffer.from(await crypto.webcrypto.subtle.exportKey('raw', kp.publicKey)).toString('base64url');
  console.log('Created notification keys');
}
const values = Object.entries(put).map(([k, v]) => `(${lit(k)}, ${lit(v)})`).join(', ');
await sql(`insert into public.app_config(key, value) values ${values} on conflict (key) do update set value = excluded.value`);
const vapidPublic = put.vapid_public || have.vapid_public;

// 7. Scheduled jobs
await sql(fs.readFileSync('supabase/sql/cron.sql', 'utf8'));
console.log('Scheduled jobs ready');

// 8. App settings file
fs.writeFileSync('web/config.js', `window.GC_CONFIG = ${JSON.stringify({ url: `https://${ref}.supabase.co`, key: browserKey, vapidPublic })};\n`);
if (process.env.GITHUB_ENV) fs.appendFileSync(process.env.GITHUB_ENV, `PROJECT_REF=${ref}\n`);
console.log('Done');
