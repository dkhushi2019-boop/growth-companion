-- Scheduled jobs (Supabase only). Safe to run many times.
do $$
begin
  begin
    create extension if not exists pg_cron with schema pg_catalog;
  exception when others then
    create extension if not exists pg_cron;
  end;
  begin
    create extension if not exists pg_net with schema extensions;
  exception when others then
    create extension if not exists pg_net;
  end;
end $$;

select cron.unschedule(jobname) from cron.job where jobname like 'gc-%';

-- Send waiting notifications every minute (only calls the server when something is waiting).
select cron.schedule('gc-send', '* * * * *', $job$
  select net.http_post(
    url := (select value from public.app_config where key = 'functions_url') || '/push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-secret', (select value from public.app_config where key = 'cron_secret')),
    body := '{}'::jsonb)
  where exists (select 1 from public.outbox where sent_at is null and attempts < 5)
$job$);

-- Test reminders: 6:00 PM India for upcoming tests, 6:45 AM India on the day.
select cron.schedule('gc-exam-evening', '30 12 * * *', $job$ select public.enqueue_exam_reminders(false) $job$);
select cron.schedule('gc-exam-morning', '15 1 * * *', $job$ select public.enqueue_exam_reminders(true) $job$);
-- Evening check-in nudge for the child at 8:50 PM India, only if something is missing.
select cron.schedule('gc-checkin', '20 15 * * *', $job$ select public.enqueue_checkin_nudge() $job$);
-- Weekly summary for the parent, Sunday 8:00 PM Dubai.
select cron.schedule('gc-weekly', '0 16 * * 0', $job$ select public.enqueue_weekly() $job$);
-- Tidy old notifications.
select cron.schedule('gc-cleanup', '10 0 * * *', $job$ delete from public.outbox where created_at < now() - interval '30 days' $job$);
