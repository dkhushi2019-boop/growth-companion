-- Growth Companion database. Safe to run many times.

-- ---------- tables ----------
create table if not exists public.families (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  family_id uuid not null references public.families(id) on delete cascade,
  role text not null check (role in ('parent','child')),
  created_at timestamptz not null default now()
);
create unique index if not exists members_one_child on public.members(family_id) where role = 'child';

-- Everything the app stores: tasks, logs, books, tests, moods, messages, plans...
create table if not exists public.items (
  family_id uuid not null references public.families(id) on delete cascade,
  kind text not null,
  key text not null,
  data jsonb not null default '{}'::jsonb,
  owner uuid not null default auth.uid(),
  updated_by uuid default auth.uid(),
  updated_at timestamptz not null default now(),
  primary key (family_id, kind, key)
);

create table if not exists public.push_subs (
  endpoint text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  family_id uuid not null references public.families(id) on delete cascade,
  role text not null,
  sub jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.outbox (
  id bigserial primary key,
  family_id uuid not null references public.families(id) on delete cascade,
  to_role text not null,
  title text not null,
  body text not null default '',
  tag text,
  created_at timestamptz not null default now(),
  sent_at timestamptz,
  attempts int not null default 0
);
create index if not exists outbox_pending on public.outbox(id) where sent_at is null;

create table if not exists public.app_config (
  key text primary key,
  value text not null
);

alter table public.families enable row level security;
alter table public.members enable row level security;
alter table public.items enable row level security;
alter table public.push_subs enable row level security;
alter table public.outbox enable row level security;
alter table public.app_config enable row level security;

-- ---------- helpers ----------
create or replace function public.my_family() returns uuid
language sql stable security definer set search_path = public as $$
  select family_id from public.members where user_id = auth.uid()
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.members where user_id = auth.uid()
$$;

-- Who may change what. Parent-only: names, goals and limits, rewards.
-- Notification choices belong to each person. Everything else is shared.
create or replace function public.can_write(k text, kkey text) returns boolean
language sql stable security definer set search_path = public as $$
  select case
    when public.my_role() is null then false
    when k in ('family','parentcfg','reward') then public.my_role() = 'parent'
    when k = 'notify' then kkey = auth.uid()::text
    else true
  end
$$;

-- ---------- access rules ----------
drop policy if exists fam_sel on public.families;
create policy fam_sel on public.families for select to authenticated
  using (id = public.my_family());

drop policy if exists mem_sel on public.members;
create policy mem_sel on public.members for select to authenticated
  using (family_id = public.my_family());

-- 'private' rows (a mood note kept private) are visible only to the person who wrote them.
drop policy if exists items_sel on public.items;
create policy items_sel on public.items for select to authenticated
  using (family_id = public.my_family() and (kind <> 'private' or owner = auth.uid()));

drop policy if exists items_ins on public.items;
create policy items_ins on public.items for insert to authenticated
  with check (family_id = public.my_family() and owner = auth.uid() and public.can_write(kind, key));

drop policy if exists items_upd on public.items;
create policy items_upd on public.items for update to authenticated
  using (family_id = public.my_family() and (kind <> 'private' or owner = auth.uid()) and public.can_write(kind, key))
  with check (family_id = public.my_family() and public.can_write(kind, key));

drop policy if exists items_del on public.items;
create policy items_del on public.items for delete to authenticated
  using (family_id = public.my_family() and (kind <> 'private' or owner = auth.uid()) and public.can_write(kind, key));

-- push_subs, outbox and app_config have no client policies: only the server reaches them.

-- ---------- guards ----------
create or replace function public.items_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.kind = 'redemption' then
    if tg_op = 'INSERT' and coalesce(new.data->>'status','pending') <> 'pending' and public.my_role() <> 'parent' then
      raise exception 'A new reward request starts as waiting.';
    end if;
    if tg_op = 'UPDATE' and (new.data->>'status') is distinct from (old.data->>'status') and public.my_role() <> 'parent' then
      raise exception 'Only the parent can answer a reward request.';
    end if;
  end if;
  if tg_op = 'UPDATE' then
    new.owner := old.owner;
  end if;
  new.updated_at := now();
  new.updated_by := auth.uid();
  return new;
end $$;
drop trigger if exists items_guard on public.items;
create trigger items_guard before insert or update on public.items
  for each row execute function public.items_guard();

-- ---------- family setup ----------
create or replace function public.create_family() returns json
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  fid uuid;
  c text;
  alpha text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  i int;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  select family_id into fid from public.members where user_id = uid;
  if fid is not null then
    return json_build_object('family_id', fid, 'code', (select code from public.families where id = fid));
  end if;
  if exists (select 1 from public.families) then
    raise exception 'This app already has a family. Sign in with the account that set it up.';
  end if;
  loop
    c := '';
    for i in 1..6 loop
      c := c || substr(alpha, 1 + floor(random() * length(alpha))::int, 1);
    end loop;
    exit when not exists (select 1 from public.families where code = c);
  end loop;
  insert into public.families(code) values (c) returning id into fid;
  insert into public.members(user_id, family_id, role) values (uid, fid, 'parent');
  return json_build_object('family_id', fid, 'code', c);
end $$;

-- ---------- notifications ----------
create or replace function public.save_push(sub jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare fid uuid := public.my_family(); r text := public.my_role();
begin
  if fid is null then raise exception 'Not part of a family yet.'; end if;
  if coalesce(sub->>'endpoint','') = '' then raise exception 'Missing endpoint.'; end if;
  insert into public.push_subs(endpoint, user_id, family_id, role, sub)
  values (sub->>'endpoint', auth.uid(), fid, r, sub)
  on conflict (endpoint) do update
    set user_id = excluded.user_id, family_id = excluded.family_id, role = excluded.role, sub = excluded.sub, created_at = now();
end $$;

create or replace function public.remove_push(p_endpoint text) returns void
language sql security definer set search_path = public as $$
  delete from public.push_subs where endpoint = p_endpoint and user_id = auth.uid()
$$;

create or replace function public.enqueue(fid uuid, to_role text, title text, body text, tag text) returns void
language sql security definer set search_path = public as $$
  insert into public.outbox(family_id, to_role, title, body, tag) values (fid, to_role, title, coalesce(body,''), tag)
$$;

create or replace function public.test_push() returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_family() is null then raise exception 'Not part of a family yet.'; end if;
  perform public.enqueue(public.my_family(), public.my_role(), 'Notifications are on', 'This is what a Growth Companion update looks like.', 'test');
end $$;

create or replace function public.fam_names(fid uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select data from public.items where family_id = fid and kind = 'family' and key = 'names'), '{}'::jsonb)
$$;

create or replace function public.parent_wants(fid uuid, k text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((
    select (i.data->>k)::boolean from public.items i
    join public.members m on m.user_id::text = i.key and m.family_id = i.family_id and m.role = 'parent'
    where i.family_id = fid and i.kind = 'notify' limit 1), true)
$$;

create or replace function public.fmt_min(m int) returns text
language sql immutable as $$
  select case when m < 60 then m || 'm'
              when m % 60 = 0 then (m / 60) || 'h'
              else (m / 60) || 'h ' || (m % 60) || 'm' end
$$;

create or replace function public.is_school_day(fid uuid, d date) returns boolean
language sql stable security definer set search_path = public as $$
  select extract(dow from d) between 1 and 6
     and not exists (select 1 from public.items where family_id = fid and kind = 'holiday' and key = d::text)
$$;

create or replace function public.screen_limit(fid uuid, d date) returns int
language sql stable security definer set search_path = public as $$
  select coalesce((
    select (data->'screenLimit'->>(case when public.is_school_day(fid, d) then 'school' else 'weekend' end))::int
    from public.items where family_id = fid and kind = 'parentcfg' and key = 'main'),
    case when public.is_school_day(fid, d) then 120 else 180 end)
$$;

create or replace function public.items_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  n jsonb := public.fam_names(new.family_id);
  child text := coalesce(nullif(n->>'child',''), 'Your child');
  parent text := coalesce(nullif(n->>'parent',''), 'Your parent');
  d jsonb := new.data;
  od jsonb := case when tg_op = 'UPDATE' then old.data else null end;
  by_child boolean := public.my_role() = 'child';
  lim int; mins int; old_mins int;
begin
  if new.kind = 'message' and tg_op = 'INSERT' then
    if d->>'from' = 'parent' then
      perform public.enqueue(new.family_id, 'child',
        case when d->>'kind' = 'remark' then parent || ' signed your diary' else 'Message from ' || parent end,
        left(coalesce(d->>'text',''), 160), 'msg');
    else
      perform public.enqueue(new.family_id, 'parent', 'Message from ' || child, left(coalesce(d->>'text',''), 160), 'msg');
    end if;
  elsif new.kind = 'task' and tg_op = 'INSERT' and d->>'from' = 'parent' then
    perform public.enqueue(new.family_id, 'child', parent || ' suggested a task', left(coalesce(d->>'title',''), 160), 'task');
  elsif not by_child then
    return new;
  elsif new.kind = 'redemption' and tg_op = 'INSERT' and public.parent_wants(new.family_id, 'reward') then
    perform public.enqueue(new.family_id, 'parent', child || ' asked for a reward',
      coalesce(d->>'title','') || ' · ' || coalesce(d->>'cost','?') || ' points', 'reward');
  elsif new.kind = 'mood' and d->>'face' in ('sad','frustrated')
        and (od is null or (od->>'face') is distinct from (d->>'face'))
        and public.parent_wants(new.family_id, 'mood') then
    perform public.enqueue(new.family_id, 'parent', child || ' is feeling ' || (d->>'face') || ' today',
      case when coalesce((d->>'share')::boolean, false) and coalesce(d->>'note','') <> '' then left(d->>'note', 160)
           else 'Maybe ask about it on your call. Listening helps more than fixing.' end, 'mood');
  elsif new.kind = 'holiday' and tg_op = 'INSERT' then
    perform public.enqueue(new.family_id, 'parent', child || ' marked a school holiday',
      to_char(new.key::date, 'Dy DD Mon') || ' is marked as no school.', 'holiday');
  elsif new.kind = 'screen' and public.parent_wants(new.family_id, 'screen') then
    lim := public.screen_limit(new.family_id, new.key::date);
    mins := coalesce((d->>'min')::int, 0);
    old_mins := coalesce((od->>'min')::int, 0);
    if mins > lim and (od is null or old_mins <= lim) then
      perform public.enqueue(new.family_id, 'parent', child || '’s screen time: ' || public.fmt_min(mins),
        public.fmt_min(mins - lim) || ' over the ' || public.fmt_min(lim) || ' limit on ' || to_char(new.key::date, 'Dy DD Mon') || '.', 'screen');
    end if;
  elsif new.kind = 'book' and coalesce(d->>'finishedOn','') <> '' and coalesce(od->>'finishedOn','') = ''
        and public.parent_wants(new.family_id, 'milestone') then
    perform public.enqueue(new.family_id, 'parent', child || ' finished a book', coalesce(d->>'title',''), 'book');
  end if;
  return new;
end $$;
drop trigger if exists items_notify on public.items;
create trigger items_notify after insert or update on public.items
  for each row execute function public.items_notify();

-- Scheduled reminders (called by cron.sql on Supabase)
create or replace function public.enqueue_exam_reminders(on_the_day boolean) returns int
language plpgsql security definer set search_path = public as $$
declare
  r record;
  t date := (now() at time zone 'Asia/Kolkata')::date;
  days int; n int := 0; title text; portion text; child text;
begin
  for r in select family_id, data from public.items where kind = 'exam' loop
    begin
      days := (r.data->>'date')::date - t;
    exception when others then continue;
    end;
    if days < 0 or (on_the_day and days <> 0) or (not on_the_day and days = 0) then continue; end if;
    if not (coalesce(r.data->'remind', '[3,1]'::jsonb) @> to_jsonb(days)) then continue; end if;
    title := coalesce(r.data->>'subject','Test') || ' ' || lower(coalesce(r.data->>'kind','test')) ||
      case when days = 0 then ' today' when days = 1 then ' tomorrow' else ' in ' || days || ' days' end;
    portion := nullif(r.data->>'portion','');
    perform public.enqueue(r.family_id, 'child', title,
      case when days = 0 then 'You’ve prepared. Do your best!'
           when days = 1 then 'A quick revision tonight, then sleep on time.'
           else 'Plan some revision time before then.' end || coalesce(' Portion: ' || portion, ''), 'exam');
    if days <= 1 and public.parent_wants(r.family_id, 'exam') then
      child := coalesce(nullif(public.fam_names(r.family_id)->>'child',''), 'Your child');
      perform public.enqueue(r.family_id, 'parent', child || ': ' || title, coalesce('Portion: ' || portion, ''), 'exam');
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.enqueue_checkin_nudge() returns int
language plpgsql security definer set search_path = public as $$
declare f record; t text := ((now() at time zone 'Asia/Kolkata')::date)::text; n int := 0; need_screen boolean; need_mood boolean;
begin
  for f in select id from public.families loop
    need_screen := not exists (select 1 from public.items where family_id = f.id and kind = 'screen' and key = t);
    need_mood := not exists (select 1 from public.items where family_id = f.id and kind = 'mood' and key = t);
    if need_screen or need_mood then
      perform public.enqueue(f.id, 'child', 'Before bed',
        case when need_screen and need_mood then 'Add today’s screen time and how you feel.'
             when need_screen then 'Add today’s screen time.'
             else 'How was your day? Do a quick mood check-in.' end, 'checkin');
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

create or replace function public.enqueue_weekly() returns int
language plpgsql security definer set search_path = public as $$
declare
  f record;
  t date := (now() at time zone 'Asia/Kolkata')::date;
  st int; rd int; ac int; sc int; sd int; child text; n int := 0;
begin
  for f in select id from public.families loop
    if not public.parent_wants(f.id, 'weekly') then continue; end if;
    select coalesce(sum((data->>'min')::int) filter (where data->>'type' = 'study'), 0),
           coalesce(sum((data->>'min')::int) filter (where data->>'type' = 'reading'), 0),
           coalesce(sum((data->>'min')::int) filter (where data->>'type' = 'activity'), 0)
      into st, rd, ac
      from public.items where family_id = f.id and kind = 'log'
       and (data->>'date') between (t - 6)::text and t::text;
    select coalesce(sum((data->>'min')::int), 0), count(*) into sc, sd
      from public.items where family_id = f.id and kind = 'screen' and key between (t - 6)::text and t::text;
    child := coalesce(nullif(public.fam_names(f.id)->>'child',''), 'Your child');
    perform public.enqueue(f.id, 'parent', child || '’s week',
      'Study ' || public.fmt_min(st) || ' · Reading ' || public.fmt_min(rd) || ' · Active ' || public.fmt_min(ac) ||
      case when sd > 0 then ' · Screen ' || public.fmt_min(sc / sd) || ' a day' else '' end, 'weekly');
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------- permissions ----------
revoke all on function public.enqueue(uuid, text, text, text, text) from public, anon, authenticated;
revoke all on function public.enqueue_exam_reminders(boolean) from public, anon, authenticated;
revoke all on function public.enqueue_checkin_nudge() from public, anon, authenticated;
revoke all on function public.enqueue_weekly() from public, anon, authenticated;
grant execute on function public.create_family() to authenticated;
grant execute on function public.save_push(jsonb) to authenticated;
grant execute on function public.remove_push(text) to authenticated;
grant execute on function public.test_push() to authenticated;

-- ---------- live updates ----------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'items') then
    execute 'alter publication supabase_realtime add table public.items';
  end if;
end $$;
