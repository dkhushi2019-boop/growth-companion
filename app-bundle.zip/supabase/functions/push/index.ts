// Sends waiting notifications. Called every minute by the database scheduler.
import { adminClient, json } from "../_shared/admin.ts";
import { buildPushRequest } from "../_shared/webpush.ts";

Deno.serve(async (req) => {
  const admin = adminClient();
  const { data: cfgRows, error: cfgErr } = await admin.from("app_config").select("key,value");
  if (cfgErr) return json({ error: cfgErr.message }, 500);
  const cfg = Object.fromEntries((cfgRows ?? []).map((r) => [r.key, r.value]));
  if (!cfg.cron_secret || req.headers.get("x-cron-secret") !== cfg.cron_secret) {
    return json({ error: "forbidden" }, 403);
  }
  const privateJWK = JSON.parse(cfg.vapid_private_jwk);
  const publicKey = cfg.vapid_public;
  const contact = cfg.site_url && cfg.site_url.startsWith("https://") ? cfg.site_url : "mailto:noreply@example.com";

  const { data: jobs, error } = await admin
    .from("outbox").select("*")
    .is("sent_at", null).lt("attempts", 5)
    .order("id").limit(50);
  if (error) return json({ error: error.message }, 500);

  let sent = 0, failed = 0;
  for (const job of jobs ?? []) {
    const { data: subs } = await admin
      .from("push_subs").select("endpoint,sub")
      .eq("family_id", job.family_id).eq("role", job.to_role);
    let delivered = (subs ?? []).length === 0; // nobody to tell: nothing more to do
    for (const s of subs ?? []) {
      try {
        const { endpoint, init } = await buildPushRequest(
          s.sub,
          { title: job.title, body: job.body, tag: job.tag, url: cfg.site_url || "./" },
          { privateJWK, publicKey, contact },
        );
        const res = await fetch(endpoint, init);
        if (res.status === 404 || res.status === 410) {
          await admin.from("push_subs").delete().eq("endpoint", s.endpoint);
        } else if (res.ok) {
          delivered = true;
        } else {
          console.log("push refused", res.status, (await res.text()).slice(0, 300));
        }
      } catch (e) {
        console.log("push error", String(e));
      }
    }
    await admin.from("outbox")
      .update(delivered ? { sent_at: new Date().toISOString(), attempts: job.attempts + 1 } : { attempts: job.attempts + 1 })
      .eq("id", job.id);
    if (delivered) sent++; else failed++;
  }
  return json({ sent, failed });
});
