// Lets the parent create the child's login, or set a new password for it.
import { adminClient, cors, json } from "../_shared/admin.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const admin = adminClient();
    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: userData, error: userErr } = await admin.auth.getUser(jwt);
    if (userErr || !userData?.user) return json({ error: "Please sign in again." }, 401);

    const { data: me } = await admin.from("members")
      .select("family_id,role").eq("user_id", userData.user.id).maybeSingle();
    if (!me || me.role !== "parent") return json({ error: "Only the parent can do this." }, 403);

    const body = await req.json().catch(() => ({}));
    const password = String(body.password ?? "");
    if (password.length < 6) return json({ error: "Use at least 6 letters or numbers." }, 400);

    const { data: fam } = await admin.from("families").select("code").eq("id", me.family_id).single();
    const code = String(fam!.code);
    const email = `child.${code.toLowerCase()}@example.com`;

    const { data: kid } = await admin.from("members")
      .select("user_id").eq("family_id", me.family_id).eq("role", "child").maybeSingle();
    if (kid) {
      const { error } = await admin.auth.admin.updateUserById(kid.user_id, { password });
      if (error) return json({ error: error.message }, 400);
      return json({ code, updated: true });
    }
    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
    });
    if (createErr || !created?.user) return json({ error: createErr?.message ?? "Could not create the login." }, 400);
    const { error: memErr } = await admin.from("members")
      .insert({ user_id: created.user.id, family_id: me.family_id, role: "child" });
    if (memErr) return json({ error: memErr.message }, 400);
    return json({ code, created: true });
  } catch (e) {
    return json({ error: String((e as Error)?.message ?? e) }, 500);
  }
});
